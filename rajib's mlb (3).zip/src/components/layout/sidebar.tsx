// src/components/layout/sidebar.tsx
'use client';

import {
  Sidebar,
  SidebarContent,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuItem,
  SidebarMenuButton,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupLabel,
} from '@/components/ui/sidebar';
import { menuList, NavGroup } from '@/lib/menu-list';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useAuth } from '@/hooks/useAuth';
import { Button } from '../ui/button';
import { LogOut } from 'lucide-react';

export function MainSidebar() {
  const pathname = usePathname();
  const { isAdmin, logout } = useAuth();

  const isActive = (href: string) => pathname === href;

  return (
    <Sidebar>
      <SidebarHeader>
        <div className="flex items-center gap-2">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="24"
            height="24"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
            className="h-8 w-8 text-primary"
          >
            <path d="M12 2a10 10 0 1 0 10 10A10 10 0 0 0 12 2z"></path>
            <path d="M15.36 18.36a5 5 0 0 0-6.72 0"></path>
            <path d="M12 12a3 3 0 1 0-3-3"></path>
            <path d="m12 12 2.2-2.2"></path>
          </svg>
          <span className="text-xl font-semibold font-headline">Rajib's MLB</span>
        </div>
      </SidebarHeader>
      <SidebarContent className="p-0">
        {menuList.map((group) => {
            if (group.title === 'Admin' && !isAdmin) {
                return null;
            }
            return (
              <SidebarGroup key={group.title}>
                <SidebarGroupLabel>{group.title}</SidebarGroupLabel>
                <SidebarMenu>
                  {group.links.map((link) => (
                    <SidebarMenuItem key={link.href}>
                      <Link href={link.href} className="w-full">
                        <SidebarMenuButton isActive={isActive(link.href)} tooltip={link.label}>
                          <link.icon />
                          <span>{link.label}</span>
                        </SidebarMenuButton>
                      </Link>
                    </SidebarMenuItem>
                  ))}
                </SidebarMenu>
              </SidebarGroup>
            )
        })}
      </SidebarContent>
      <SidebarFooter>
        <Button variant="ghost" className="w-full justify-start" onClick={logout}>
            <LogOut className="mr-2 h-4 w-4" />
            Logout
        </Button>
      </SidebarFooter>
    </Sidebar>
  );
}
