// src/app/api/pbp-stats/route.ts
import { NextResponse } from 'next/server';
import { fetchPlayerVsPlayerStats } from '@/lib/mlb-stats';
import { unstable_noStore as noStore } from 'next/cache';

export async function GET(request: Request) {
  noStore();
  const { searchParams } = new URL(request.url);
  const batterName = searchParams.get('batterName');
  const pitcherName = searchParams.get('pitcherName');

  if (!batterName || !pitcherName) {
    return NextResponse.json({ detail: 'batterName and pitcherName are required' }, { status: 400 });
  }
  
  try {
    const stats = await fetchPlayerVsPlayerStats(batterName, pitcherName);
    return NextResponse.json(stats);
  } catch (error: any) {
     console.error(`An error occurred in pbp-stats API route:`, error);
     return NextResponse.json({ detail: error.message || 'An internal server error occurred.' }, { status: 500 });
  }
}
