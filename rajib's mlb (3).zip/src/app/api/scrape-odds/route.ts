// pages/api/scrape-odds.ts
import type { NextApiRequest, NextApiResponse } from 'next';

// Type definitions
interface GameOdds {
  awayTeam: string;
  homeTeam: string;
  gameTime: string;
  odds: {
    away: string;
    home: string;
  };
  scrapedAt: string;
}

interface LineMovement {
  time: string;
  spread: string;
  total: string;
}

interface ApiResponse {
  success: boolean;
  games?: GameOdds[];
  lineMovement?: LineMovement[];
  timestamp: string;
  error?: string;
}

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse<ApiResponse>
) {
  // Set CORS headers
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    res.status(200).end();
    return;
  }

  if (req.method !== 'GET') {
    return res.status(405).json({ 
      success: false,
      error: 'Method not allowed',
      timestamp: new Date().toISOString()
    });
  }

  try {
    // Mock data for testing - replace with actual scraping logic later
    const mockGames: GameOdds[] = [
      {
        awayTeam: "New York Yankees",
        homeTeam: "Boston Red Sox",
        gameTime: "7:05 PM ET",
        odds: {
          away: "-150",
          home: "+130"
        },
        scrapedAt: new Date().toISOString()
      },
      {
        awayTeam: "Los Angeles Dodgers",
        homeTeam: "San Francisco Giants",
        gameTime: "10:15 PM ET",
        odds: {
          away: "-110",
          home: "-110"
        },
        scrapedAt: new Date().toISOString()
      },
      {
        awayTeam: "Houston Astros",
        homeTeam: "Seattle Mariners",
        gameTime: "9:40 PM ET",
        odds: {
          away: "+105",
          home: "-125"
        },
        scrapedAt: new Date().toISOString()
      }
    ];

    const mockLineMovement: LineMovement[] = [
      {
        time: "2:00 PM",
        spread: "Yankees -1.5",
        total: "O 8.5"
      },
      {
        time: "3:30 PM",
        spread: "Yankees -1.5",
        total: "O 9.0"
      },
      {
        time: "4:45 PM",
        spread: "Yankees -1.0",
        total: "O 9.0"
      }
    ];

    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 1000));

    const response: ApiResponse = {
      success: true,
      games: mockGames,
      lineMovement: mockLineMovement,
      timestamp: new Date().toISOString()
    };

    res.status(200).json(response);

  } catch (error) {
    console.error('API Error:', error);
    
    const errorResponse: ApiResponse = {
      success: false,
      error: error instanceof Error ? error.message : 'Unknown error',
      timestamp: new Date().toISOString()
    };

    res.status(500).json(errorResponse);
  }
}