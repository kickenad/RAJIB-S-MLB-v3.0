// src/app/api/payments/webhook/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { doc, getDoc, updateDoc, setDoc } from 'firebase/firestore';
import { db } from '@/lib/firebase.config';
import { sendEmail } from '@/lib/email-service';
import { type NOWPaymentsWebhook } from '@/types/payment';
import crypto from 'crypto';

const NOWPAYMENTS_IPN_SECRET = process.env.NOWPAYMENTS_IPN_SECRET;

function verifySignature(body: string, signature: string): boolean {
  if (!NOWPAYMENTS_IPN_SECRET) return false;
  
  const hmac = crypto.createHmac('sha512', NOWPAYMENTS_IPN_SECRET);
  hmac.update(body);
  const computedSignature = hmac.digest('hex');
  
  return computedSignature === signature;
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.text();
    const signature = request.headers.get('x-nowpayments-sig');

    // Verify webhook signature
    if (!signature || !verifySignature(body, signature)) {
      console.error('Invalid webhook signature');
      return NextResponse.json({ error: 'Invalid signature' }, { status: 401 });
    }

    const webhookData: NOWPaymentsWebhook = JSON.parse(body);
    const { order_id, payment_status, actually_paid, price_amount } = webhookData;

    console.log('Webhook received:', { order_id, payment_status, actually_paid, price_amount });

    // Find the invoice by order_id
    const invoicesRef = db.collection('invoices');
    const invoiceQuery = await invoicesRef.where('orderId', '==', order_id).get();

    if (invoiceQuery.empty) {
      console.error('Invoice not found for order:', order_id);
      return NextResponse.json({ error: 'Invoice not found' }, { status: 404 });
    }

    const invoiceDoc = invoiceQuery.docs[0];
    const invoice = invoiceDoc.data();
    const invoiceId = invoiceDoc.id;

    // Update invoice status
    let newStatus = 'pending';
    switch (payment_status) {
      case 'confirming':
        newStatus = 'confirming';
        break;
      case 'confirmed':
      case 'finished':
        // Check if payment amount matches
        if (actually_paid >= price_amount) {
          newStatus = 'confirmed';
        } else {
          newStatus = 'failed';
          console.error('Payment amount mismatch:', { actually_paid, price_amount });
        }
        break;
      case 'failed':
      case 'expired':
        newStatus = 'failed';
        break;
      case 'refunded':
        newStatus = 'refunded';
        break;
    }

    // Update invoice
    await updateDoc(doc(db, 'invoices', invoiceId), {
      status: newStatus,
      actuallyPaid: actually_paid,
      paymentStatus: payment_status,
      updatedAt: new Date(),
      ...(newStatus === 'confirmed' && { paidAt: new Date() }),
    });

    // If payment is confirmed, create/update subscription
    if (newStatus === 'confirmed') {
      const startDate = new Date();
      const endDate = new Date(startDate.getTime() + (invoice.planDuration * 24 * 60 * 60 * 1000));

      const subscriptionData = {
        id: `sub_${invoice.userId}_${Date.now()}`,
        userId: invoice.userId,
        planId: invoice.planId,
        status: 'active',
        startDate,
        endDate,
        autoRenew: false,
        invoiceId,
        createdAt: new Date(),
        updatedAt: new Date(),
      };

      await setDoc(doc(db, 'subscriptions', invoice.userId), subscriptionData);

      // Send success email to user
      try {
        await sendEmail({
          to: invoice.customerEmail,
          subject: 'Payment Confirmed - Welcome to Rajib\'s MLB Analysis!',
          template: 'payment-success',
          data: {
            customerName: invoice.customerEmail.split('@')[0],
            planName: invoice.planName,
            amount: invoice.amount,
            startDate: startDate.toISOString(),
            endDate: endDate.toISOString(),
            loginUrl: `${process.env.NEXT_PUBLIC_APP_URL}/auth/signin`,
          },
        });
      } catch (emailError) {
        console.error('Failed to send success email:', emailError);
      }

      // Send admin notification
      try {
        await sendEmail({
          to: process.env.ADMIN_EMAIL || 'admin@example.com',
          subject: 'Payment Confirmed - New Subscriber',
          template: 'admin-payment-success',
          data: {
            customerEmail: invoice.customerEmail,
            planName: invoice.planName,
            amount: invoice.amount,
            userId: invoice.userId,
            invoiceId,
            subscriptionEndDate: endDate.toISOString(),
          },
        });
      } catch (emailError) {
        console.error('Failed to send admin notification:', emailError);
      }

      console.log('Subscription activated for user:', invoice.userId);
    }

    // Handle failed payments
    if (newStatus === 'failed') {
      try {
        await sendEmail({
          to: invoice.customerEmail,
          subject: 'Payment Failed - Rajib\'s MLB Analysis',
          template: 'payment-failed',
          data: {
            customerName: invoice.customerEmail.split('@')[0],
            planName: invoice.planName,
            amount: invoice.amount,
            invoiceId,
            retryUrl: `${process.env.NEXT_PUBLIC_APP_URL}/pricing`,
          },
        });
      } catch (emailError) {
        console.error('Failed to send failure email:', emailError);
      }
    }

    return NextResponse.json({ success: true });

  } catch (error: any) {
    console.error('Webhook processing error:', error);
    return NextResponse.json({ 
      error: 'Webhook processing failed',
      details: error.message 
    }, { status: 500 });
  }
}