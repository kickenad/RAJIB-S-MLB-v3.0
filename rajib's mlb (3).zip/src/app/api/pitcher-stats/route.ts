// src/app/api/pitcher-stats/route.ts
import { NextResponse } from 'next/server';
import { fetchPitcherStats } from '@/lib/mlb-stats';


// --- API ENDPOINT ---
export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const pitcherIdStr = searchParams.get('pitcherId');

  if (!pitcherIdStr) {
    return NextResponse.json({ detail: 'pitcherId is required' }, { status: 400 });
  }

  const pitcherId = parseInt(pitcherIdStr, 10);
  if (isNaN(pitcherId)) {
    return NextResponse.json({ detail: 'Invalid pitcherId' }, { status: 400 });
  }
  
  try {
    const stats = await fetchPitcherStats(pitcherId);
    if (!stats) {
        return NextResponse.json(null, { status: 404, statusText: 'No pitching stats found for current season.' });
    }
    return NextResponse.json(stats);
  } catch (error) {
     console.error(`An error occurred in pitcher-stats API route for pitcher ${pitcherId}:`, error);
     return NextResponse.json({ detail: 'An internal server error occurred.' }, { status: 500 });
  }
}
