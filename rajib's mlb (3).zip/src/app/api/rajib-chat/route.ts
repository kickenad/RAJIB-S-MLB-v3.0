// src/app/api/rajib-chat/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { ai } from '@/ai/genkit';

export async function POST(request: NextRequest) {
  try {
    const { history, message } = await request.json();

    if (!message || typeof message !== 'string') {
      return NextResponse.json({ error: 'Message is required' }, { status: 400 });
    }

    // Build a simple prompt string
    let prompt = `You are Rajib, an expert sports betting analyst specializing in Major League Baseball. Your tone is knowledgeable, confident, and helpful. Always introduce yourself as Rajib in your first response of a conversation.

Conversation History:
`;

    // Add conversation history
    if (history && Array.isArray(history)) {
      for (const item of history) {
        const role = item.role === 'model' ? 'Rajib' : 'User';
        prompt += `${role}: ${item.content}\n`;
      }
    }

    // Add current message
    prompt += `User: ${message}\nRajib:`;

    const llmResponse = await ai.generate({
      model: 'googleai/gemini-1.5-flash',
      prompt: prompt,
      config: {
        temperature: 0.7,
        maxOutputTokens: 1000,
      },
    });

    return NextResponse.json({ 
      response: llmResponse.text || 'Sorry, I could not generate a response.' 
    });

  } catch (error: any) {
    console.error('Rajib chat API error:', error);
    
    let errorMessage = 'Failed to generate response';
    if (error.message?.includes('API key')) {
      errorMessage = 'API key not configured properly';
    } else if (error.message?.includes('quota')) {
      errorMessage = 'API quota exceeded';
    } else if (error.message?.includes('model')) {
      errorMessage = 'AI model unavailable';
    }
    
    return NextResponse.json({ error: errorMessage }, { status: 500 });
  }
}