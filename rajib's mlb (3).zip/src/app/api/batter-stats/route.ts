// src/app/api/batter-stats/route.ts
import { NextResponse } from 'next/server';
import { fetchBatterStats } from '@/lib/mlb-stats';


// --- API ENDPOINT ---
export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const playerIdStr = searchParams.get('playerId');

  if (!playerIdStr) {
    return NextResponse.json({ detail: 'playerId is required' }, { status: 400 });
  }

  const playerId = parseInt(playerIdStr, 10);
  if (isNaN(playerId)) {
    return NextResponse.json({ detail: 'Invalid playerId' }, { status: 400 });
  }
  
  try {
    const stats = await fetchBatterStats(playerId);
    
    if (!stats) {
       return NextResponse.json(null, { status: 404, statusText: 'No hitting stats found for current season.' });
    }
    
    return NextResponse.json(stats);
  } catch (error) {
     console.error(`An error occurred in batter-stats API route for player ${playerId}:`, error);
     return NextResponse.json({ detail: 'An internal server error occurred.' }, { status: 500 });
  }
}
