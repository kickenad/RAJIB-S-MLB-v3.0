// src/app/api/auth/route.ts
import { NextResponse } from 'next/server';
import { auth } from '../../../lib/firebaseadmin';

export async function POST(request: Request) {
  const { idToken } = await request.json();

  const expiresIn = 60 * 60 * 24 * 5 * 1000; // 5 days

  try {
    const sessionCookie = await auth.createSessionCookie(idToken, { expiresIn });
    const options = {
      name: 'session',
      value: sessionCookie,
      maxAge: expiresIn,
      httpOnly: true,
      secure: true,
    };

    const response = NextResponse.json({}, { status: 200 });
    response.cookies.set(options);
    return response;
  } catch (error) {
    return NextResponse.json({ error: 'Failed to create session cookie' }, { status: 401 });
  }
}
