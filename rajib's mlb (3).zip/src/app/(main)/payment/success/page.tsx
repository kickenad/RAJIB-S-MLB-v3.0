// src/app/(main)/payment/success/page.tsx
'use client';

import React, { useEffect, useState } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from '@/components/ui/button';
import { CheckCircle2, Loader2, AlertCircle } from 'lucide-react';
import { useAuth } from '@/hooks/useAuth';

export default function PaymentSuccessPage() {
  const [status, setStatus] = useState<'loading' | 'success' | 'pending' | 'error'>('loading');
  const [paymentDetails, setPaymentDetails] = useState<any>(null);
  const router = useRouter();
  const searchParams = useSearchParams();
  const { user } = useAuth();
  const invoiceId = searchParams.get('invoice');

  useEffect(() => {
    if (!invoiceId) {
      setStatus('error');
      return;
    }

    const checkPaymentStatus = async () => {
      try {
        const response = await fetch(`/api/payments/status/${invoiceId}`);
        if (!response.ok) {
          throw new Error('Failed to fetch payment status');
        }

        const data = await response.json();
        setPaymentDetails(data);

        switch (data.status) {
          case 'confirmed':
            setStatus('success');
            break;
          case 'pending':
          case 'confirming':
            setStatus('pending');
            // Poll for updates
            setTimeout(checkPaymentStatus, 5000);
            break;
          default:
            setStatus('error');
        }
      } catch (error) {
        console.error('Error checking payment status:', error);
        setStatus('error');
      }
    };

    checkPaymentStatus();
  }, [invoiceId]);

  const handleContinue = () => {
    // Clear any pending invoice from localStorage
    localStorage.removeItem('pendingInvoice');
    router.push('/picks/trap-detector');
  };

  if (status === 'loading') {
    return (
      <div className="container mx-auto px-4 py-16 max-w-2xl">
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-16">
            <Loader2 className="h-12 w-12 animate-spin text-primary mb-4" />
            <h2 className="text-2xl font-semibold mb-2">Checking Payment Status</h2>
            <p className="text-muted-foreground text-center">
              Please wait while we verify your payment...
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (status === 'success') {
    return (
      <div className="container mx-auto px-4 py-16 max-w-2xl">
        <Card>
          <CardHeader className="text-center">
            <div className="flex justify-center mb-4">
              <CheckCircle2 className="h-16 w-16 text-green-500" />
            </div>
            <CardTitle className="text-3xl text-green-600">Payment Successful! 🎉</CardTitle>
          </CardHeader>
          <CardContent className="text-center space-y-6">
            <p className="text-lg text-muted-foreground">
              Your subscription has been activated successfully.
            </p>
            
            {paymentDetails && (
              <div className="bg-green-50 p-6 rounded-lg border border-green-200">
                <h3 className="font-semibold text-green-800 mb-4">Subscription Details</h3>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-green-700">Plan:</span>
                    <span className="font-medium">{paymentDetails.planName}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-green-700">Amount:</span>
                    <span className="font-medium">${paymentDetails.amount}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-green-700">Valid Until:</span>
                    <span className="font-medium">
                      {paymentDetails.endDate ? new Date(paymentDetails.endDate).toLocaleDateString() : 'N/A'}
                    </span>
                  </div>
                </div>
              </div>
            )}

            <div className="space-y-4">
              <h3 className="text-xl font-semibold">What's Next?</h3>
              <ul className="text-left space-y-2 max-w-md mx-auto">
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="h-4 w-4 text-green-500" />
                  <span>Access trap detection for all MLB games</span>
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="h-4 w-4 text-green-500" />
                  <span>Get signals across 18 betting markets</span>
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="h-4 w-4 text-green-500" />
                  <span>Receive final picks with risk management</span>
                </li>
              </ul>
            </div>

            <Button onClick={handleContinue} size="lg" className="w-full">
              Start Analyzing Games
            </Button>

            <p className="text-sm text-muted-foreground">
              You should also receive a confirmation email shortly.
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (status === 'pending') {
    return (
      <div className="container mx-auto px-4 py-16 max-w-2xl">
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-16">
            <Loader2 className="h-12 w-12 animate-spin text-yellow-500 mb-4" />
            <h2 className="text-2xl font-semibold mb-2">Payment Confirming</h2>
            <p className="text-muted-foreground text-center mb-4">
              Your payment is being processed. This usually takes a few minutes.
            </p>
            <p className="text-sm text-muted-foreground text-center">
              You'll receive an email once the payment is confirmed.
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-16 max-w-2xl">
      <Card>
        <CardHeader className="text-center">
          <div className="flex justify-center mb-4">
            <AlertCircle className="h-16 w-16 text-red-500" />
          </div>
          <CardTitle className="text-3xl text-red-600">Payment Issue</CardTitle>
        </CardHeader>
        <CardContent className="text-center space-y-6">
          <p className="text-lg text-muted-foreground">
            There was an issue with your payment. Please try again or contact support.
          </p>
          
          <div className="space-y-4">
            <Button onClick={() => router.push('/pricing')} size="lg">
              Try Again
            </Button>
            <Button variant="outline" onClick={() => router.push('/contact')}>
              Contact Support
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

// src/app/(main)/payment/cancelled/page.tsx
'use client';

import React from 'react';
import { useRouter } from 'next/navigation';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from '@/components/ui/button';
import { XCircle } from 'lucide-react';

export default function PaymentCancelledPage() {
  const router = useRouter();

  return (
    <div className="container mx-auto px-4 py-16 max-w-2xl">
      <Card>
        <CardHeader className="text-center">
          <div className="flex justify-center mb-4">
            <XCircle className="h-16 w-16 text-gray-500" />
          </div>
          <CardTitle className="text-3xl text-gray-600">Payment Cancelled</CardTitle>
        </CardHeader>
        <CardContent className="text-center space-y-6">
          <p className="text-lg text-muted-foreground">
            Your payment was cancelled. No charges were made to your account.
          </p>
          
          <div className="space-y-4">
            <Button onClick={() => router.push('/pricing')} size="lg">
              Try Again
            </Button>
            <Button variant="outline" onClick={() => router.push('/')}>
              Return Home
            </Button>
          </div>
          
          <p className="text-sm text-muted-foreground">
            Need help? Contact us at support@rajibsmlb.com
          </p>
        </CardContent>
      </Card>
    </div>
  );
}