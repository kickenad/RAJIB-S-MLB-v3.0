// src/app/(main)/picks/signal-analysis/page.tsx
'use client';

import React, { useState, useEffect, useCallback } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Loader2, TrendingUp, AlertTriangle, Target, Zap, Star, X } from 'lucide-react';
import { analyzeMarketSignals, type SignalAnalysisInput, type SignalAnalysisOutput, type MarketSignalType } from '@/ai/flows/signal-analysis';
import { getGamesForDate, type MlbGame } from '@/lib/mlb';
import { format } from 'date-fns';
import { toZonedTime } from 'date-fns-tz';
import { cn } from '@/lib/utils';

interface GameForSignalAnalysis extends MlbGame {
    signalAnalysis?: SignalAnalysisOutput | null;
    loading: boolean;
    error?: string | null;
}

function SignalStrengthBadge({ strength }: { strength: string }) {
    const colors = {
        'VERY_STRONG': 'bg-green-500',
        'STRONG': 'bg-blue-500', 
        'MODERATE': 'bg-yellow-500',
        'WEAK': 'bg-gray-500'
    };
    
    return (
        <Badge className={cn("text-white", colors[strength as keyof typeof colors])}>
            {strength.replace('_', ' ')}
        </Badge>
    );
}

function MarketSignalCard({ signal }: { signal: MarketSignalType }) {
    const getDirectionIcon = (direction: string) => {
        switch(direction) {
            case 'OVER': return '↗️';
            case 'UNDER': return '↘️';
            case 'YES': return '✅';
            case 'NO': return '❌';
            case 'HOME': return '🏠';
            case 'AWAY': return '✈️';
            default: return '📊';
        }
    };

    const getRiskColor = (risk: string) => {
        switch(risk) {
            case 'LOW': return 'text-green-600';
            case 'MEDIUM': return 'text-yellow-600';
            case 'HIGH': return 'text-red-600';
            default: return 'text-gray-600';
        }
    };

    return (
        <Card className="mb-4">
            <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                    <CardTitle className="text-lg flex items-center gap-2">
                        {getDirectionIcon(signal.direction)}
                        {signal.market.replace(/_/g, ' ')}
                    </CardTitle>
                    <div className="flex items-center gap-2">
                        <SignalStrengthBadge strength={signal.strength} />
                        <Badge variant="outline">{signal.confidence}%</Badge>
                    </div>
                </div>
                <CardDescription className="flex items-center justify-between">
                    <span>{signal.direction} {signal.value && `(${signal.value})`}</span>
                    <span className={cn("font-medium", getRiskColor(signal.riskLevel))}>
                        {signal.unitSize} units • {signal.riskLevel} risk
                    </span>
                </CardDescription>
            </CardHeader>
            <CardContent>
                <p className="text-sm text-muted-foreground mb-3">{signal.reasoning}</p>
                <div>
                    <h5 className="text-sm font-semibold mb-2">Key Factors:</h5>
                    <ul className="text-sm space-y-1">
                        {signal.keyFactors.map((factor, index) => (
                            <li key={index} className="flex items-start gap-2">
                                <span className="text-primary">•</span>
                                <span>{factor}</span>
                            </li>
                        ))}
                    </ul>
                </div>
                {signal.expectedValue && (
                    <div className="mt-3 pt-3 border-t">
                        <span className="text-sm font-medium">Expected Value: </span>
                        <span className={cn("text-sm font-bold", signal.expectedValue > 0 ? "text-green-600" : "text-red-600")}>
                            {signal.expectedValue > 0 ? '+' : ''}{signal.expectedValue.toFixed(2)}%
                        </span>
                    </div>
                )}
            </CardContent>
        </Card>
    );
}

function SignalAnalysisDisplay({ analysis }: { analysis: SignalAnalysisOutput }) {
    return (
        <div className="mt-4 space-y-6">
            {/* Summary */}
            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                        <TrendingUp className="h-5 w-5" />
                        Analysis Summary
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
                        <div className="text-center">
                            <div className="text-2xl font-bold text-primary">{analysis.signals.length}</div>
                            <div className="text-sm text-muted-foreground">Total Signals</div>
                        </div>
                        <div className="text-center">
                            <div className="text-2xl font-bold text-green-600">{analysis.topPicks.length}</div>
                            <div className="text-sm text-muted-foreground">Top Picks</div>
                        </div>
                        <div className="text-center">
                            <div className="text-2xl font-bold text-blue-600">{analysis.overallConfidence}%</div>
                            <div className="text-sm text-muted-foreground">Confidence</div>
                        </div>
                        <div className="text-center">
                            <div className="text-2xl font-bold text-purple-600">{analysis.recommendedBankroll}%</div>
                            <div className="text-sm text-muted-foreground">Bankroll Use</div>
                        </div>
                    </div>
                    <p className="text-sm text-muted-foreground">{analysis.summary}</p>
                    <div className="mt-3 p-3 bg-amber-50 rounded-lg border border-amber-200">
                        <h5 className="font-semibold text-amber-800 mb-1">Risk Assessment:</h5>
                        <p className="text-sm text-amber-700">{analysis.riskAssessment}</p>
                    </div>
                </CardContent>
            </Card>

            {/* Tabs for different market categories */}
            <Tabs defaultValue="top-picks" className="w-full">
                <TabsList className="grid w-full grid-cols-5">
                    <TabsTrigger value="top-picks" className="flex items-center gap-1">
                        <Star className="h-4 w-4" />
                        Top Picks
                    </TabsTrigger>
                    <TabsTrigger value="match">Match Markets</TabsTrigger>
                    <TabsTrigger value="team">Team Markets</TabsTrigger>
                    <TabsTrigger value="player">Player Markets</TabsTrigger>
                    <TabsTrigger value="avoid">Avoid</TabsTrigger>
                </TabsList>
                
                <TabsContent value="top-picks" className="space-y-4">
                    <h3 className="text-lg font-semibold flex items-center gap-2">
                        <Star className="h-5 w-5 text-yellow-500" />
                        Recommended Bets
                    </h3>
                    {analysis.topPicks.map((signal, index) => (
                        <MarketSignalCard key={index} signal={signal} />
                    ))}
                </TabsContent>

                <TabsContent value="match" className="space-y-4">
                    <h3 className="text-lg font-semibold">Match Markets (6)</h3>
                    {analysis.signals
                        .filter(s => s.market.startsWith('MATCH_'))
                        .map((signal, index) => (
                            <MarketSignalCard key={index} signal={signal} />
                        ))}
                </TabsContent>

                <TabsContent value="team" className="space-y-4">
                    <h3 className="text-lg font-semibold">Team Markets (5)</h3>
                    {analysis.signals
                        .filter(s => s.market.startsWith('TEAM_'))
                        .map((signal, index) => (
                            <MarketSignalCard key={index} signal={signal} />
                        ))}
                </TabsContent>

                <TabsContent value="player" className="space-y-4">
                    <h3 className="text-lg font-semibold">Player Markets (7)</h3>
                    {analysis.signals
                        .filter(s => s.market.startsWith('PLAYER_'))
                        .map((signal, index) => (
                            <MarketSignalCard key={index} signal={signal} />
                        ))}
                </TabsContent>

                <TabsContent value="avoid" className="space-y-4">
                    <h3 className="text-lg font-semibold flex items-center gap-2">
                        <X className="h-5 w-5 text-red-500" />
                        Bets to Avoid
                    </h3>
                    {analysis.avoidBets.map((avoid, index) => (
                        <Card key={index} className="border-red-200">
                            <CardContent className="pt-4">
                                <div className="flex items-center gap-2 mb-2">
                                    <X className="h-4 w-4 text-red-500" />
                                    <span className="font-medium">{avoid.market.replace(/_/g, ' ')}</span>
                                </div>
                                <p className="text-sm text-muted-foreground">{avoid.reason}</p>
                            </CardContent>
                        </Card>
                    ))}
                </TabsContent>
            </Tabs>
        </div>
    );
}

function GameSignalCard({ game, onAnalyze }: { 
    game: GameForSignalAnalysis; 
    onAnalyze: (gamePk: number) => void; 
}) {
    const gameTimeET = toZonedTime(game.gameDate, 'America/New_York');
    const formattedTime = format(gameTimeET, 'p');

    return (
        <Card>
            <CardHeader>
                <CardTitle>{game.teams.away.team.name} @ {game.teams.home.team.name}</CardTitle>
                <CardDescription>{formattedTime} ET at {game.venue.name}</CardDescription>
            </CardHeader>
            <CardContent>
                {game.signalAnalysis && <SignalAnalysisDisplay analysis={game.signalAnalysis} />}
                {game.error && <p className="text-destructive text-sm mt-4">{game.error}</p>}
            </CardContent>
            <CardFooter>
                <Button onClick={() => onAnalyze(game.gamePk)} disabled={game.loading} className="w-full">
                    {game.loading ? (
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    ) : (
                        <Zap className="mr-2 h-4 w-4" />
                    )}
                    {game.signalAnalysis ? 'Re-Analyze Signals' : 'Analyze Market Signals'}
                </Button>
            </CardFooter>
        </Card>
    );
}

export default function SignalAnalysisPage() {
    const [games, setGames] = useState<GameForSignalAnalysis[]>([]);
    const [loadingInitial, setLoadingInitial] = useState(true);

    const fetchGames = useCallback(async () => {
        setLoadingInitial(true);
        try {
            const todayStr = format(new Date(), 'yyyy-MM-dd');
            const dailyGames = await getGamesForDate(todayStr);
            setGames(dailyGames.map(g => ({ ...g, loading: false })));
        } catch (e) {
            console.error('Failed to fetch games:', e);
            setGames([]);
        } finally {
            setLoadingInitial(false);
        }
    }, []);

    useEffect(() => {
        fetchGames();
    }, [fetchGames]);

    const handleSignalAnalysis = async (gamePk: number) => {
        setGames(prev => prev.map(g => g.gamePk === gamePk ? { ...g, loading: true, error: null } : g));

        const game = games.find(g => g.gamePk === gamePk);
        if (!game) return;

        try {
            // Mock input data - replace with actual data fetching
            const analysisInput: SignalAnalysisInput = {
                gameDetails: `${game.teams.away.team.name} @ ${game.teams.home.team.name}`,
                trapAnalysis: {
                    isTrap: false, // This would come from your trap analysis
                    confidence: 70,
                },
                matchData: {
                    probablePitchers: "Pitcher stats and matchup data here",
                    pitcherStats: "Detailed pitcher statistics",
                    teamStats: "Team offensive/defensive stats", 
                    h2hHistory: "Head to head history",
                    parkFactors: "Ballpark factors and dimensions",
                },
                teamData: {
                    homeTeamStats: "Home team recent statistics",
                    awayTeamStats: "Away team recent statistics",
                    recentForm: "Team form over last 10 games",
                    bullpenStatus: "Bullpen usage and availability",
                    injuries: "Key player injury reports",
                },
                playerData: {
                    keyPlayers: "Key player analysis",
                    lineups: "Expected batting lineups",
                    playerVsPitcher: "Player vs pitcher matchups",
                    playerForm: "Individual player recent form",
                    playerProps: "Available player prop odds",
                },
                marketOdds: {
                    matchMarkets: "Match market odds and lines",
                    teamMarkets: "Team market odds and lines", 
                    playerMarkets: "Player prop odds and lines",
                },
                weather: "Weather conditions and forecasts",
                umpireData: "Home plate umpire tendencies",
            };
            
            const result = await analyzeMarketSignals(analysisInput);
            setGames(prev => prev.map(g => g.gamePk === gamePk ? { ...g, loading: false, signalAnalysis: result } : g));
        
        } catch (e: any) {
            console.error("Signal analysis error: ", e);
            setGames(prev => prev.map(g => g.gamePk === gamePk ? { 
                ...g, 
                loading: false, 
                error: "Signal analysis failed. Please try again.",
                signalAnalysis: null 
            } : g));
        }
    };

    if (loadingInitial) {
        return (
            <div className="flex flex-col items-center gap-4 text-muted-foreground pt-16">
                <Loader2 className="h-10 w-10 animate-spin text-accent" />
                <p className="font-medium">Loading games for signal analysis...</p>
            </div>
        );
    }

    return (
        <div className="space-y-6">
            <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
                <div>
                    <h1 className="text-3xl font-bold tracking-tight flex items-center gap-2">
                        <Target className="h-7 w-7 text-primary" />
                        Market Signal Analysis
                    </h1>
                    <p className="text-muted-foreground">
                        Analyze betting signals across 18 approved markets for precise picks.
                    </p>
                </div>
                <Button onClick={fetchGames} disabled={loadingInitial} variant="outline">
                    <Loader2 className={loadingInitial ? "animate-spin mr-2 h-4 w-4" : "mr-2 h-4 w-4"} />
                    Refresh Games
                </Button>
            </div>

            <div className="space-y-6">
                {games.map(game => (
                    <GameSignalCard key={game.gamePk} game={game} onAnalyze={handleSignalAnalysis} />
                ))}
            </div>
        </div>
    );
}