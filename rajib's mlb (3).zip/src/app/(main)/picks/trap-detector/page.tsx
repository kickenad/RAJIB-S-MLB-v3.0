// src/app/(main)/picks/trap-detector/page.tsx
'use client';

import React, { useState, useEffect, useCallback } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Button } from '@/components/ui/button';
import { Loader2, ShieldAlert, RefreshCw, AlertTriangle, Sparkles, Gamepad2, ShieldCheck } from 'lucide-react';
import { analyzeBettingTraps, type AnalyzeBettingTrapsInput, type AnalyzeBettingTrapsOutput } from '@/ai/flows/analyze-betting-traps';
import { getGamesForDate, type MlbGame } from '@/lib/mlb';
import { format } from 'date-fns';
import { toZonedTime } from 'date-fns-tz';
import { getFunctions, httpsCallable } from 'firebase/functions';
import { app } from '@/lib/firebase.config';
import { type GameOdds } from '@/app/(main)/analysis/live-odds/page';
import { fetchPitcherStats } from '@/lib/mlb-stats';
import { bullpenUsageData } from '@/lib/bullpenData';

interface GameForAnalysis extends MlbGame {
    analysis?: AnalyzeBettingTrapsOutput | null;
    loading: boolean;
    error?: string | null;
}

function TrapAnalysisDisplay({ analysis }: { analysis: AnalyzeBettingTrapsOutput }) {
    return (
        <div className={`mt-4 p-4 rounded-lg ${analysis.isTrap ? 'bg-destructive/10 border-destructive/20' : 'bg-green-500/10 border-green-500/20'} border`}>
            <h3 className={`flex items-center gap-2 font-bold ${analysis.isTrap ? 'text-destructive' : 'text-green-400'}`}>
                {analysis.isTrap ? <AlertTriangle /> : <ShieldCheck />}
                {analysis.isTrap ? 'TRAP DETECTED' : 'NO TRAP DETECTED'}
            </h3>
            <p className="text-sm text-muted-foreground mt-2">{analysis.summary}</p>
            <div className="mt-4">
                <h4 className="font-semibold text-xs mb-2">Key Factors:</h4>
                <ul className="list-disc pl-5 space-y-1 text-xs text-muted-foreground">
                    {analysis.keyFactors.map((factor, index) => <li key={index}>{factor}</li>)}
                </ul>
            </div>
             {analysis.suggestedBet && (
                <div className="mt-4 pt-3 border-t border-border/50">
                    <h4 className="font-semibold text-xs mb-1">Suggested Bet:</h4>
                    <p className="text-sm font-bold text-foreground">{analysis.suggestedBet}</p>
                    <p className="text-xs text-muted-foreground">Risk Level: {analysis.riskLevel}</p>
                </div>
            )}
        </div>
    );
}

function GameAnalysisCard({ game, onAnalyze }: { game: GameForAnalysis; onAnalyze: (gamePk: number) => void; }) {
    const gameTimeET = toZonedTime(game.gameDate, 'America/New_York');
    const formattedTime = format(gameTimeET, 'p');

    return (
        <Card>
            <CardHeader>
                <CardTitle>{game.teams.away.team.name} @ {game.teams.home.team.name}</CardTitle>
                <CardDescription>{formattedTime} ET at {game.venue.name}</CardDescription>
            </CardHeader>
            <CardContent>
                {game.analysis && <TrapAnalysisDisplay analysis={game.analysis} />}
                {game.error && <p className="text-destructive text-sm mt-4">{game.error}</p>}
            </CardContent>
            <CardFooter>
                <Button onClick={() => onAnalyze(game.gamePk)} disabled={game.loading} className="w-full">
                    {game.loading ? (
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    ) : (
                        <Sparkles className="mr-2 h-4 w-4" />
                    )}
                    {game.analysis ? 'Re-Analyze Traps' : 'Analyze for Traps'}
                </Button>
            </CardFooter>
        </Card>
    )
}

export default function TrapDetectorPage() {
    const [games, setGames] = useState<GameForAnalysis[]>([]);
    const [liveOdds, setLiveOdds] = useState<GameOdds[]>([]);
    const [loadingInitial, setLoadingInitial] = useState(true);

    const fetchGamesAndOdds = useCallback(async () => {
        setLoadingInitial(true);
        try {
            const todayStr = format(new Date(), 'yyyy-MM-dd');
            const dailyGames = await getGamesForDate(todayStr);
            setGames(dailyGames.map(g => ({ ...g, loading: false })));

            // Add error handling for Firebase function call
            try {
                const functions = getFunctions(app);
                const getLiveOdds = httpsCallable(functions, 'getLiveScrapedOdds');
                const result: any = await getLiveOdds();
                
                if (result?.data?.games) {
                    setLiveOdds(result.data.games);
                } else {
                    console.warn('No odds data received from Firebase function');
                    setLiveOdds([]);
                }
            } catch (oddsError) {
                console.error('Failed to fetch live odds:', oddsError);
                setLiveOdds([]); // Continue without odds data
            }

        } catch (e) {
            console.error('Failed to fetch games:', e);
            setGames([]);
        } finally {
            setLoadingInitial(false);
        }
    }, []);

    useEffect(() => {
        fetchGamesAndOdds();
    }, [fetchGamesAndOdds]);

    const handleAnalysis = async (gamePk: number) => {
        setGames(prev => prev.map(g => g.gamePk === gamePk ? { ...g, loading: true, error: null } : g));

        const game = games.find(g => g.gamePk === gamePk);
        if (!game) {
            console.error('Game not found for analysis');
            return;
        }

        try {
            // Add null checks for pitcher IDs
            const awayPitcherId = game.teams.away.probablePitcher?.id;
            const homePitcherId = game.teams.home.probablePitcher?.id;

            // Fetch pitcher stats with error handling
            const [awayPitcherStats, homePitcherStats] = await Promise.allSettled([
                awayPitcherId ? fetchPitcherStats(awayPitcherId) : Promise.resolve(null),
                homePitcherId ? fetchPitcherStats(homePitcherId) : Promise.resolve(null)
            ]);

            const awayStats = awayPitcherStats.status === 'fulfilled' ? awayPitcherStats.value : null;
            const homeStats = homePitcherStats.status === 'fulfilled' ? homePitcherStats.value : null;

            // Find matching odds with better error handling
            const gameOdds = liveOdds.find(o => {
                const homeMatch = o.home_team?.toLowerCase().includes(game.teams.home.team.name.toLowerCase().split(' ').pop() || '');
                const awayMatch = o.away_team?.toLowerCase().includes(game.teams.away.team.name.toLowerCase().split(' ').pop() || '');
                return homeMatch && awayMatch;
            });

            // Get bullpen data safely
            const awayBullpen = bullpenUsageData?.bullpenUsage?.[game.teams.away.team.name] || [];
            const homeBullpen = bullpenUsageData?.bullpenUsage?.[game.teams.home.team.name] || [];

            const analysisInput: AnalyzeBettingTrapsInput = {
                gameDetails: `${game.teams.away.team.name} @ ${game.teams.home.team.name} (${game.venue.name})`,
                probablePitchers: `Away: ${game.teams.away.probablePitcher?.fullName || 'TBD'} (ERA: ${awayStats?.era || 'N/A'}, WHIP: ${awayStats?.whip || 'N/A'}) vs. Home: ${game.teams.home.probablePitcher?.fullName || 'TBD'} (ERA: ${homeStats?.era || 'N/A'}, WHIP: ${homeStats?.whip || 'N/A'})`,
                liveOdds: gameOdds ? 
                    `Moneyline: ${gameOdds.bookmakers?.[0]?.markets?.find(m => m.key === 'h2h')?.outcomes?.map(o => `${o.name}: ${o.price}`)?.join(', ') || 'N/A'}` :
                    "No live odds available for this matchup.",
                weather: "Weather data integration pending.", 
                injuries: "Injury data integration pending.", 
                bullpenData: awayBullpen.length > 0 || homeBullpen.length > 0 ? 
                    `Away bullpen recent usage: ${awayBullpen.slice(0, 3).map(p => `${p.playerName}: ${p.last3DaysPitches}p/3d`).join(', ')}. Home: ${homeBullpen.slice(0, 3).map(p => `${p.playerName}: ${p.last3DaysPitches}p/3d`).join(', ')}` :
                    "Bullpen usage data not available.",
                keyBatterStats: "Key batter vs pitcher matchup data integration pending.", 
            };
            
            // Call the server action with proper error handling
            const result = await analyzeBettingTraps(analysisInput);
            
            if (!result) {
                throw new Error('Analysis returned no results');
            }

            setGames(prev => prev.map(g => 
                g.gamePk === gamePk ? { ...g, loading: false, analysis: result, error: null } : g
            ));
        
        } catch (error: any) {
            console.error("Analysis error:", error);
            
            let errorMessage = "Analysis failed. ";
            if (error?.message?.includes('Model')) {
                errorMessage += "AI model is unavailable. Please try again later.";
            } else if (error?.message?.includes('network')) {
                errorMessage += "Network error. Check your connection.";
            } else {
                errorMessage += "Please try again or contact support if the issue persists.";
            }
            
            setGames(prev => prev.map(g => 
                g.gamePk === gamePk ? { ...g, loading: false, error: errorMessage, analysis: null } : g
            ));
        }
    };

    const renderContent = () => {
        if (loadingInitial) {
            return (
                <div className="flex flex-col items-center gap-4 text-muted-foreground pt-16">
                    <Loader2 className="h-10 w-10 animate-spin text-accent" />
                    <p className="font-medium">Fetching today's games and live odds...</p>
                </div>
            )
        }

        if (games.length === 0) {
            return (
                 <div className="flex flex-col items-center justify-center text-center py-16 text-muted-foreground">
                    <Gamepad2 className="h-12 w-12 mb-4" />
                    <h3 className="text-xl font-semibold text-foreground">No Games Today</h3>
                    <p>There are no games scheduled for today.</p>
                </div>
            )
        }

        return (
             <div className="grid gap-6 md:grid-cols-2 xl:grid-cols-3">
                {games.map(game => (
                    <GameAnalysisCard key={game.gamePk} game={game} onAnalyze={handleAnalysis} />
                ))}
            </div>
        )
    }

    return (
        <div className="space-y-6">
            <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
                <div>
                    <h1 className="text-3xl font-bold tracking-tight flex items-center gap-2">
                        <ShieldAlert className="h-7 w-7 text-primary" />
                        Betting Trap Detector
                    </h1>
                    <p className="text-muted-foreground">
                        Use our AI to analyze game variables and identify potential trap bets for today's games.
                    </p>
                </div>
                 <Button onClick={fetchGamesAndOdds} disabled={loadingInitial} variant="outline">
                    <RefreshCw className={loadingInitial ? "animate-spin mr-2 h-4 w-4" : "mr-2 h-4 w-4"} />
                    Refresh Games
                </Button>
            </div>
            {renderContent()}
        </div>
    );
}