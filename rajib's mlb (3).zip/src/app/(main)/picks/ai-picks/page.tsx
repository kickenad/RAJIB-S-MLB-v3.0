// src/app/(main)/picks/final-picks/page.tsx
'use client';

import React, { useState, useEffect, useCallback } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Separator } from '@/components/ui/separator';
import { 
  Loader2, 
  Target, 
  DollarSign, 
  TrendingUp, 
  AlertTriangle, 
  Lock, 
  Star, 
  Activity,
  RefreshCw,
  Settings,
  CheckCircle2
} from 'lucide-react';
import { generateFinalPicks, type FinalPicksInput, type FinalPicksOutput, type FinalPick } from '@/ai/flows/final-picks-generator';
import { getGamesForDate, type MlbGame } from '@/lib/mlb';
import { format } from 'date-fns';
import { toZonedTime } from 'date-fns-tz';
import { cn } from '@/lib/utils';

interface GameForFinalPicks extends MlbGame {
    finalPicks?: FinalPicksOutput | null;
    loading: boolean;
    error?: string | null;
}

interface BankrollSettings {
  totalBankroll: number;
  maxRiskPerGame: number;
  currentExposure: number;
  minConfidence: number;
  minExpectedValue: number;
  maxBetsPerGame: number;
}

function PriorityBadge({ priority }: { priority: string }) {
    const colors = {
        'LOCK': 'bg-green-600 text-white',
        'STRONG': 'bg-blue-600 text-white',
        'VALUE': 'bg-purple-600 text-white',
        'HEDGE': 'bg-gray-600 text-white'
    };
    
    const icons = {
        'LOCK': <Lock className="h-3 w-3" />,
        'STRONG': <Star className="h-3 w-3" />,
        'VALUE': <TrendingUp className="h-3 w-3" />,
        'HEDGE': <Activity className="h-3 w-3" />
    };
    
    return (
        <Badge className={cn("flex items-center gap-1", colors[priority as keyof typeof colors])}>
            {icons[priority as keyof typeof icons]}
            {priority}
        </Badge>
    );
}

function RiskLevelBadge({ risk }: { risk: string }) {
    const colors = {
        'LOW': 'bg-green-100 text-green-800 border-green-200',
        'MEDIUM': 'bg-yellow-100 text-yellow-800 border-yellow-200',
        'HIGH': 'bg-red-100 text-red-800 border-red-200'
    };
    
    return (
        <Badge variant="outline" className={colors[risk as keyof typeof colors]}>
            {risk} RISK
        </Badge>
    );
}

function FinalPickCard({ pick, bankroll }: { pick: FinalPick; bankroll: number }) {
    const profitIfWin = (pick.odds - 1) * pick.stake;
    const roi = ((profitIfWin / pick.stake) * 100);
    
    return (
        <Card className="mb-4 border-l-4 border-l-primary">
            <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                        <PriorityBadge priority={pick.priority} />
                        <div>
                            <CardTitle className="text-lg">{pick.market}</CardTitle>
                            <CardDescription className="font-medium">{pick.selection}</CardDescription>
                        </div>
                    </div>
                    <div className="text-right">
                        <div className="text-2xl font-bold">{pick.odds > 0 ? '+' : ''}{pick.odds}</div>
                        <div className="text-sm text-muted-foreground">{pick.confidence}% confidence</div>
                    </div>
                </div>
            </CardHeader>
            <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
                    <div className="text-center">
                        <div className="text-xl font-bold text-green-600">${pick.stake}</div>
                        <div className="text-sm text-muted-foreground">Stake</div>
                    </div>
                    <div className="text-center">
                        <div className="text-xl font-bold text-blue-600">{pick.unitSize}u</div>
                        <div className="text-sm text-muted-foreground">Units</div>
                    </div>
                    <div className="text-center">
                        <div className="text-xl font-bold text-purple-600">+{roi.toFixed(1)}%</div>
                        <div className="text-sm text-muted-foreground">ROI</div>
                    </div>
                    <div className="text-center">
                        <div className="text-xl font-bold text-orange-600">${profitIfWin.toFixed(0)}</div>
                        <div className="text-sm text-muted-foreground">If Win</div>
                    </div>
                </div>
                
                <div className="flex items-center gap-2 mb-3">
                    <RiskLevelBadge risk={pick.riskLevel} />
                    <Badge variant="outline">
                        EV: {pick.expectedValue > 0 ? '+' : ''}{pick.expectedValue.toFixed(1)}%
                    </Badge>
                </div>
                
                <p className="text-sm text-muted-foreground">{pick.reasoning}</p>
            </CardContent>
        </Card>
    );
}

function FinalPicksDisplay({ picks, bankroll }: { picks: FinalPicksOutput; bankroll: number }) {
    const totalProfit = picks.finalPicks.reduce((sum, pick) => {
        return sum + ((pick.odds - 1) * pick.stake);
    }, 0);
    
    const riskColors = {
        1: 'text-green-600',
        2: 'text-green-600', 
        3: 'text-green-600',
        4: 'text-yellow-600',
        5: 'text-yellow-600',
        6: 'text-yellow-600',
        7: 'text-orange-600',
        8: 'text-red-600',
        9: 'text-red-600',
        10: 'text-red-600'
    };
    
    return (
        <div className="mt-6 space-y-6">
            {/* Summary Stats */}
            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                        <Target className="h-5 w-5" />
                        Final Picks Summary
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-4">
                        <div className="text-center">
                            <div className="text-2xl font-bold text-primary">{picks.finalPicks.length}</div>
                            <div className="text-sm text-muted-foreground">Total Picks</div>
                        </div>
                        <div className="text-center">
                            <div className="text-2xl font-bold text-green-600">${picks.totalStake}</div>
                            <div className="text-sm text-muted-foreground">Total Stake</div>
                        </div>
                        <div className="text-center">
                            <div className="text-2xl font-bold text-blue-600">{picks.totalUnits}u</div>
                            <div className="text-sm text-muted-foreground">Total Units</div>
                        </div>
                        <div className="text-center">
                            <div className="text-2xl font-bold text-purple-600">+{picks.expectedROI.toFixed(1)}%</div>
                            <div className="text-sm text-muted-foreground">Expected ROI</div>
                        </div>
                        <div className="text-center">
                            <div className={cn("text-2xl font-bold", riskColors[picks.riskScore as keyof typeof riskColors])}>
                                {picks.riskScore}/10
                            </div>
                            <div className="text-sm text-muted-foreground">Risk Score</div>
                        </div>
                    </div>
                    
                    <div className="space-y-3">
                        <div className="flex justify-between items-center">
                            <span className="text-sm font-medium">Bankroll Usage:</span>
                            <span className="text-sm font-bold">{picks.bankrollUsage.toFixed(1)}%</span>
                        </div>
                        <div className="flex justify-between items-center">
                            <span className="text-sm font-medium">Potential Profit:</span>
                            <span className="text-sm font-bold text-green-600">+${totalProfit.toFixed(0)}</span>
                        </div>
                    </div>
                    
                    <Separator className="my-4" />
                    <p className="text-sm text-muted-foreground">{picks.picksSummary}</p>
                    
                    {picks.correlationWarnings.length > 0 && (
                        <div className="mt-4 p-3 bg-amber-50 rounded-lg border border-amber-200">
                            <h5 className="font-semibold text-amber-800 mb-2 flex items-center gap-2">
                                <AlertTriangle className="h-4 w-4" />
                                Correlation Warnings:
                            </h5>
                            <ul className="text-sm text-amber-700 space-y-1">
                                {picks.correlationWarnings.map((warning, index) => (
                                    <li key={index}>• {warning}</li>
                                ))}
                            </ul>
                        </div>
                    )}
                </CardContent>
            </Card>
            
            {/* Main Picks */}
            <div>
                <h3 className="text-xl font-semibold mb-4 flex items-center gap-2">
                    <CheckCircle2 className="h-5 w-5 text-green-500" />
                    Recommended Bets
                </h3>
                {picks.finalPicks.map((pick, index) => (
                    <FinalPickCard key={index} pick={pick} bankroll={bankroll} />
                ))}
            </div>
            
            {/* Alternative Picks */}
            {picks.alternativePicks.length > 0 && (
                <div>
                    <h3 className="text-lg font-semibold mb-4">Alternative Options</h3>
                    {picks.alternativePicks.map((pick, index) => (
                        <FinalPickCard key={index} pick={pick} bankroll={bankroll} />
                    ))}
                </div>
            )}
        </div>
    );
}

function BankrollSettingsCard({ 
    settings, 
    onUpdate 
}: { 
    settings: BankrollSettings; 
    onUpdate: (settings: BankrollSettings) => void;
}) {
    const [localSettings, setLocalSettings] = useState(settings);
    
    const handleSave = () => {
        onUpdate(localSettings);
    };
    
    return (
        <Card>
            <CardHeader>
                <CardTitle className="flex items-center gap-2">
                    <Settings className="h-5 w-5" />
                    Risk Management Settings
                </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                    <div>
                        <Label htmlFor="bankroll">Total Bankroll ($)</Label>
                        <Input
                            id="bankroll"
                            type="number"
                            value={localSettings.totalBankroll}
                            onChange={(e) => setLocalSettings(prev => ({ 
                                ...prev, 
                                totalBankroll: Number(e.target.value) 
                            }))}
                        />
                    </div>
                    <div>
                        <Label htmlFor="maxRisk">Max Risk Per Game (%)</Label>
                        <Input
                            id="maxRisk"
                            type="number"
                            max="20"
                            value={localSettings.maxRiskPerGame}
                            onChange={(e) => setLocalSettings(prev => ({ 
                                ...prev, 
                                maxRiskPerGame: Number(e.target.value) 
                            }))}
                        />
                    </div>
                    <div>
                        <Label htmlFor="minConfidence">Min Confidence (%)</Label>
                        <Input
                            id="minConfidence"
                            type="number"
                            min="60"
                            max="95"
                            value={localSettings.minConfidence}
                            onChange={(e) => setLocalSettings(prev => ({ 
                                ...prev, 
                                minConfidence: Number(e.target.value) 
                            }))}
                        />
                    </div>
                    <div>
                        <Label htmlFor="maxBets">Max Bets Per Game</Label>
                        <Input
                            id="maxBets"
                            type="number"
                            min="1"
                            max="5"
                            value={localSettings.maxBetsPerGame}
                            onChange={(e) => setLocalSettings(prev => ({ 
                                ...prev, 
                                maxBetsPerGame: Number(e.target.value) 
                            }))}
                        />
                    </div>
                </div>
            </CardContent>
            <CardFooter>
                <Button onClick={handleSave} className="w-full">
                    Update Settings
                </Button>
            </CardFooter>
        </Card>
    );
}

export default function FinalPicksPage() {
    const [games, setGames] = useState<GameForFinalPicks[]>([]);
    const [loadingInitial, setLoadingInitial] = useState(true);
    const [bankrollSettings, setBankrollSettings] = useState<BankrollSettings>({
        totalBankroll: 1000,
        maxRiskPerGame: 10,
        currentExposure: 0,
        minConfidence: 70,
        minExpectedValue: 5,
        maxBetsPerGame: 3,
    });

    const fetchGames = useCallback(async () => {
        setLoadingInitial(true);
        try {
            const todayStr = format(new Date(), 'yyyy-MM-dd');
            const dailyGames = await getGamesForDate(todayStr);
            setGames(dailyGames.map(g => ({ ...g, loading: false })));
        } catch (e) {
            console.error('Failed to fetch games:', e);
            setGames([]);
        } finally {
            setLoadingInitial(false);
        }
    }, []);

    useEffect(() => {
        fetchGames();
    }, [fetchGames]);

    const handleGeneratePicks = async (gamePk: number) => {
        setGames(prev => prev.map(g => g.gamePk === gamePk ? { ...g, loading: true, error: null } : g));

        const game = games.find(g => g.gamePk === gamePk);
        if (!game) return;

        try {
            // Mock input - in real app, this would come from previous analyses
            const picksInput: FinalPicksInput = {
                gameDetails: `${game.teams.away.team.name} @ ${game.teams.home.team.name}`,
                trapAnalysis: {
                    isTrap: false,
                    confidence: 75,
                    recommendation: 'TAKE_VALUE',
                    trapSide: 'AWAY',
                    valueSide: 'HOME',
                    summary: "Mock trap analysis result",
                    keyFactors: ["Factor 1", "Factor 2"],
                    riskLevel: 'MEDIUM'
                } as any,
                signalAnalysis: {
                    signals: [],
                    topPicks: [],
                    avoidBets: [],
                    overallConfidence: 78,
                    recommendedBankroll: 15,
                    summary: "Mock signal analysis",
                    riskAssessment: "Moderate risk"
                } as any,
                bankrollManagement: {
                    totalBankroll: bankrollSettings.totalBankroll,
                    maxRiskPerGame: bankrollSettings.maxRiskPerGame,
                    currentExposure: bankrollSettings.currentExposure,
                },
                marketLimits: {
                    maxBetsPerGame: bankrollSettings.maxBetsPerGame,
                    minConfidence: bankrollSettings.minConfidence,
                    minExpectedValue: bankrollSettings.minExpectedValue,
                },
            };
            
            const result = await generateFinalPicks(picksInput);
            setGames(prev => prev.map(g => g.gamePk === gamePk ? { ...g, loading: false, finalPicks: result } : g));
        
        } catch (e: any) {
            console.error("Final picks generation error: ", e);
            setGames(prev => prev.map(g => g.gamePk === gamePk ? { 
                ...g, 
                loading: false, 
                error: "Failed to generate final picks. Please try again.",
                finalPicks: null 
            } : g));
        }
    };

    if (loadingInitial) {
        return (
            <div className="flex flex-col items-center gap-4 text-muted-foreground pt-16">
                <Loader2 className="h-10 w-10 animate-spin text-accent" />
                <p className="font-medium">Loading games for final picks...</p>
            </div>
        );
    }

    return (
        <div className="space-y-6">
            <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
                <div>
                    <h1 className="text-3xl font-bold tracking-tight flex items-center gap-2">
                        <DollarSign className="h-7 w-7 text-primary" />
                        Final Picks Generator
                    </h1>
                    <p className="text-muted-foreground">
                        Generate final betting picks combining trap analysis and market signals with risk management.
                    </p>
                </div>
                <Button onClick={fetchGames} disabled={loadingInitial} variant="outline">
                    <RefreshCw className={loadingInitial ? "animate-spin mr-2 h-4 w-4" : "mr-2 h-4 w-4"} />
                    Refresh Games
                </Button>
            </div>

            <Tabs defaultValue="picks" className="w-full">
                <TabsList>
                    <TabsTrigger value="picks">Generate Picks</TabsTrigger>
                    <TabsTrigger value="settings">Risk Settings</TabsTrigger>
                </TabsList>
                
                <TabsContent value="picks" className="space-y-6">
                    {games.map(game => {
                        const gameTimeET = toZonedTime(game.gameDate, 'America/New_York');
                        const formattedTime = format(gameTimeET, 'p');
                        
                        return (
                            <Card key={game.gamePk}>
                                <CardHeader>
                                    <CardTitle>{game.teams.away.team.name} @ {game.teams.home.team.name}</CardTitle>
                                    <CardDescription>{formattedTime} ET at {game.venue.name}</CardDescription>
                                </CardHeader>
                                <CardContent>
                                    {game.finalPicks && (
                                        <FinalPicksDisplay picks={game.finalPicks} bankroll={bankrollSettings.totalBankroll} />
                                    )}
                                    {game.error && <p className="text-destructive text-sm mt-4">{game.error}</p>}
                                </CardContent>
                                <CardFooter>
                                    <Button 
                                        onClick={() => handleGeneratePicks(game.gamePk)} 
                                        disabled={game.loading} 
                                        className="w-full"
                                    >
                                        {game.loading ? (
                                            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                                        ) : (
                                            <Target className="mr-2 h-4 w-4" />
                                        )}
                                        {game.finalPicks ? 'Regenerate Final Picks' : 'Generate Final Picks'}
                                    </Button>
                                </CardFooter>
                            </Card>
                        );
                    })}
                </TabsContent>
                
                <TabsContent value="settings">
                    <BankrollSettingsCard 
                        settings={bankrollSettings}
                        onUpdate={setBankrollSettings}
                    />
                </TabsContent>
            </Tabs>
        </div>
    );
}