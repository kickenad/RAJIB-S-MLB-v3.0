// src/app/(main)/pricing/page.tsx
'use client';

import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Loader2, Check, Star, Zap, Crown } from 'lucide-react';
import { useAuth } from '@/hooks/useAuth'; 
import { useRouter } from 'next/navigation';
import { toast } from 'sonner';
import { SUBSCRIPTION_PLANS, type SubscriptionPlan } from '@/types/payment';
import { cn } from '@/lib/utils';

function PlanCard({ 
  plan, 
  isLoading, 
  onSelect 
}: { 
  plan: SubscriptionPlan; 
  isLoading: boolean;
  onSelect: (planId: string) => void;
}) {
  const getPlanIcon = (planId: string) => {
    switch (planId) {
      case 'weekly': return <Zap className="h-6 w-6" />;
      case 'monthly': return <Star className="h-6 w-6" />;
      case 'yearly': return <Crown className="h-6 w-6" />;
      default: return <Check className="h-6 w-6" />;
    }
  };

  const getPlanColor = (planId: string) => {
    switch (planId) {
      case 'weekly': return 'border-blue-300 hover:border-blue-400';
      case 'monthly': return 'border-purple-300 hover:border-purple-400 ring-2 ring-purple-200';
      case 'yearly': return 'border-yellow-300 hover:border-yellow-400';
      default: return 'border-gray-300 hover:border-gray-400';
    }
  };

  const getButtonColor = (planId: string) => {
    switch (planId) {
      case 'weekly': return 'bg-blue-600 hover:bg-blue-700';
      case 'monthly': return 'bg-purple-600 hover:bg-purple-700';
      case 'yearly': return 'bg-yellow-600 hover:bg-yellow-700';
      default: return 'bg-gray-600 hover:bg-gray-700';
    }
  };

  return (
    <Card className={cn(
      "relative flex flex-col transition-all duration-300 hover:shadow-xl",
      getPlanColor(plan.id),
      plan.popular ? "scale-105 shadow-lg" : "hover:scale-105"
    )}>
      {plan.popular && (
        <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
          <Badge className="bg-purple-600 text-white px-4 py-1 text-sm font-bold">
            Most Popular
          </Badge>
        </div>
      )}
      
      <CardHeader className="text-center pb-4">
        <div className="flex items-center justify-center mb-4 text-primary h-8">
          {getPlanIcon(plan.id)}
        </div>
        <CardTitle className="text-3xl font-extrabold">{plan.name}</CardTitle>
        <CardDescription className="text-md text-muted-foreground">
          {plan.duration === 7 ? 'Perfect for a trial run' : plan.duration === 30 ? 'For dedicated fans' : 'For the ultimate advantage'}
        </CardDescription>
      </CardHeader>
      
      <CardContent className="flex-grow space-y-6">
        <div className="text-center">
          <span className="text-5xl font-bold">${plan.price}</span>
          <span className="text-lg text-muted-foreground">/{plan.id.replace('ly','')}</span>
        </div>
        
        <div className="space-y-3 pt-4 border-t">
          <h4 className="font-semibold text-center text-sm uppercase text-muted-foreground">What's included</h4>
          <ul className="space-y-2">
            {plan.features.map((feature, index) => (
              <li key={index} className="flex items-start gap-3 text-sm">
                <Check className="h-5 w-5 text-green-500 mt-0.5 flex-shrink-0" />
                <span>{feature}</span>
              </li>
            ))}
          </ul>
        </div>
      </CardContent>
      
      <CardFooter>
        <Button 
          onClick={() => onSelect(plan.id)}
          disabled={isLoading}
          className={cn("w-full text-white font-bold py-6 text-lg", getButtonColor(plan.id))}
        >
          {isLoading ? (
            <Loader2 className="mr-2 h-5 w-5 animate-spin" />
          ) : (
            null
          )}
          {isLoading ? 'Processing...' : `Get ${plan.name}`}
        </Button>
      </CardFooter>
    </Card>
  );
}

export default function PricingPage() {
  const [loadingPlan, setLoadingPlan] = useState<string | null>(null);
  const { user, loading: authLoading } = useAuth();
  const router = useRouter();

  const handlePlanSelect = async (planId: string) => {
    if (!user) {
      toast.error('Please sign in to choose a plan.');
      router.push('/login?redirect=/pricing');
      return;
    }

    setLoadingPlan(planId);
    
    try {
      const response = await fetch('/api/payments/create-invoice', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          planId,
          userId: user.uid,
          customerEmail: user.email,
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Failed to create payment invoice.');
      }
      
      toast.success('Redirecting to secure payment page...');
      
      window.location.href = data.invoiceUrl;
      
    } catch (error: any) {
      console.error('Payment initiation error:', error);
      toast.error(error.message || 'An error occurred. Please try again.');
    } finally {
      setLoadingPlan(null);
    }
  };

  if (authLoading) {
    return (
      <div className="flex items-center justify-center h-[80vh]">
        <Loader2 className="h-12 w-12 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="bg-gray-50/50">
        <div className="container mx-auto px-4 py-12 md:py-24">
        <div className="text-center mb-16">
            <h1 className="text-5xl font-extrabold tracking-tight mb-4">
            Unlock Your Winning Edge
            </h1>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Access expert MLB analysis, powered by Rajib. We cover all the angles—trap detection, market signals, and final picks—so you can bet with confidence.
            </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8 max-w-7xl mx-auto">
            {SUBSCRIPTION_PLANS.map((plan) => (
            <PlanCard
                key={plan.id}
                plan={plan}
                isLoading={loadingPlan === plan.id}
                onSelect={handlePlanSelect}
            />
            ))}
        </div>

        <div className="text-center mt-20 p-8 bg-white rounded-xl shadow-md max-w-4xl mx-auto border">
            <h4 className="text-2xl font-bold mb-2">Secure and Anonymous Payments</h4>
            <p className="text-muted-foreground mb-6">
            Your privacy is paramount. We use NOWPayments to process all transactions securely. Choose from over 100 cryptocurrencies for anonymous and fast payments.
            </p>
            <div className="flex items-center justify-center gap-6 text-sm text-muted-foreground">
            <span>✓ End-to-End Encryption</span>
            <span>✓ No Personal Data Stored</span>
            <span>✓ Instant Subscription Activation</span>
            </div>
        </div>
        </div>
    </div>
  );
}
