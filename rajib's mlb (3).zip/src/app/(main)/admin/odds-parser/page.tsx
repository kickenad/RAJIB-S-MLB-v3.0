// src/app/(main)/admin/odds-parser/page.tsx
'use client';

import React, { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { getFunctions, httpsCallable } from 'firebase/functions';
import { app } from '@/lib/firebase.config';
import { Loader2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

// Helper to remove undefined values from objects, which Firestore cannot handle.
const cleanUndefined = (obj: any): any => {
  if (Array.isArray(obj)) {
    return obj.map(v => cleanUndefined(v));
  } else if (obj !== null && typeof obj === 'object') {
    return Object.keys(obj).reduce((acc, key) => {
      const value = cleanUndefined(obj[key]);
      if (value !== undefined) {
        (acc as any)[key] = value;
      }
      return acc;
    }, {});
  }
  return obj;
};


const OddsParserPage: React.FC = () => {
    const [loading, setLoading] = useState(false);
    const { toast } = useToast();
    
    useEffect(() => {
        class OddsParser {
            rawData: string;
            lines: string[];
            currentIndex: number;
            matchMarkets: any[];
            teams: Record<string, any>;
            currentTeam: string | null;
            
            constructor(rawData: string) {
                this.rawData = rawData;
                this.lines = rawData.split('\n').map(line => line.trim()).filter(line => line);
                this.currentIndex = 0;
                this.matchMarkets = [];
                this.teams = {};
                this.currentTeam = null;
            }

            parse() {
                while (this.currentIndex < this.lines.length) {
                    const line = this.lines[this.currentIndex];
                    if (line.startsWith('Match')) {
                        this.parseMatchMarket();
                    } else if (this.isTeamName(line)) {
                        this.currentTeam = line;
                        if (!this.teams[line]) this.teams[line] = { teamMarkets: [], players: [] };
                        this.currentIndex++;
                        const nextLine = this.lines[this.currentIndex];
                        if (nextLine && nextLine.trim() === 'Team Markets') {
                            this.currentIndex++;
                            this.parseTeamMarkets();
                        }
                    } else if (this.isPlayerName(line)) {
                        this.parsePlayerProps();
                    } else {
                        this.currentIndex++;
                    }
                }
                return { matchMarkets: this.matchMarkets, teams: this.teams };
            }

            isTeamName(line: string) {
                const mlbTeams = [
                    "Arizona Diamondbacks","Atlanta Braves","Baltimore Orioles","Boston Red Sox","Chicago Cubs","Chicago White Sox",
                    "Cincinnati Reds","Cleveland Guardians","Colorado Rockies","Detroit Tigers","Houston Astros","Kansas City Royals",
                    "Los Angeles Angels","Los Angeles Dodgers","Miami Marlins","Milwaukee Brewers","Minnesota Twins","New York Yankees",
                    "New York Mets","Oakland Athletics","Philadelphia Phillies","Pittsburgh Pirates","San Diego Padres","San Francisco Giants",
                    "Seattle Mariners","St. Louis Cardinals","Tampa Bay Rays","Texas Rangers","Toronto Blue Jays","Washington Nationals"
                ];
                return mlbTeams.includes(line);
            }
            isPlayerName(line: string) { return line.includes('(') && line.includes(')'); }

            parseMatchMarket() {
                const name = this.lines[this.currentIndex];
                this.currentIndex++;
                const options = [];
                while (this.currentIndex < this.lines.length) {
                    const line = this.lines[this.currentIndex];
                    if (line.startsWith('Match') || this.isTeamName(line) || this.isPlayerName(line)) break;
                    options.push(line);
                    this.currentIndex++;
                }
                this.matchMarkets.push({ name, options });
            }

            parseTeamMarkets() {
                while (this.currentIndex < this.lines.length) {
                    const line = this.lines[this.currentIndex];
                    if (this.isTeamName(line) || this.isPlayerName(line) || line.startsWith('Match')) break;
                    if (line.startsWith('Team')) {
                        const market = {
                            key: `team-${this.currentTeam?.replace(/\s/g, '_')}-${this.teams[this.currentTeam!].teamMarkets.length}`,
                            name: line,
                            outcomes: [
                                { name: 'Over', point: parseFloat(this.lines[this.currentIndex + 1]) || 0, price: parseFloat(this.lines[this.currentIndex + 3]) || 0 },
                                { name: 'Under', point: parseFloat(this.lines[this.currentIndex + 1]) || 0, price: parseFloat(this.lines[this.currentIndex + 5]) || 0 },
                            ]
                        };
                        this.teams[this.currentTeam!].teamMarkets.push(market);
                        this.currentIndex += 6;
                    } else {
                        this.currentIndex++;
                    }
                }
            }

            parsePlayerProps() {
                const line = this.lines[this.currentIndex];
                const playerInfo = line.match(/^(.+?) \(([A-Z0-9]{1,3})\)$/);
                if (!playerInfo) { this.currentIndex++; return; }
                const player = { name: playerInfo[1], position: playerInfo[2], markets: [] as any[] };
                this.currentIndex++;
                while (this.currentIndex < this.lines.length) {
                    const marketLine = this.lines[this.currentIndex];
                    if (this.isTeamName(marketLine) || this.isPlayerName(marketLine) || marketLine.startsWith('Match')) break;
                    if (this.isNumeric(this.lines[this.currentIndex + 1])) {
                        player.markets.push({
                            key: `${player.name.replace(/\s/g, '_')}-${player.markets.length}`,
                            name: marketLine,
                            outcomes: [
                                { name: 'Over', description: player.name, point: parseFloat(this.lines[this.currentIndex + 1]) || 0, price: parseFloat(this.lines[this.currentIndex + 3]) || 0 },
                                { name: 'Under', description: player.name, point: parseFloat(this.lines[this.currentIndex + 1]) || 0, price: parseFloat(this.lines[this.currentIndex + 5]) || 0 },
                            ]
                        });
                        this.currentIndex += 6;
                    } else {
                        this.currentIndex++;
                    }
                }
                this.teams[this.currentTeam!].players.push(player);
            }
            isNumeric(str: string) { return str && !isNaN(parseFloat(str)); }
        }

        const parseAndSave = async () => {
            setLoading(true);
            const inputEl = document.getElementById('propsInput') as HTMLTextAreaElement;
            const rawData = inputEl.value;
            if (!rawData.trim()) {
                toast({ title: 'Error', description: 'Please paste odds data first.', variant: 'destructive' });
                setLoading(false);
                return;
            }

            const parser = new OddsParser(rawData);
            const result = parser.parse();

            const teams = Object.keys(result.teams);
            if (teams.length !== 2) {
                toast({ title: 'Parsing Error', description: 'Could not determine the two teams in the matchup. Please check the pasted data.', variant: 'destructive' });
                setLoading(false);
                return;
            }

            const home_team = teams[0];
            const away_team = teams[1];
            
            const gameId = `${away_team.replace(/\s/g, '_')}_vs_${home_team.replace(/\s/g, '_')}`;

            const allPlayerMarkets = Object.values(result.teams).flatMap((teamData: any) => 
                teamData.players.flatMap((player: any) => player.markets)
            );
            
            const allTeamMarkets = Object.values(result.teams).flatMap((teamData: any) => teamData.teamMarkets);
            
            const manualBookmaker = {
                key: 'manual',
                title: 'Manual Odds',
                last_update: new Date().toISOString(),
                markets: [...allPlayerMarkets, ...allTeamMarkets]
            };

            const gameOdds = {
                id: gameId,
                sport_key: 'baseball_mlb',
                sport_title: 'MLB',
                commence_time: new Date().toISOString(),
                home_team,
                away_team,
                bookmakers: [manualBookmaker]
            };

            try {
                const functions = getFunctions(app);
                const saveParsedOdds = httpsCallable(functions, 'saveParsedOdds');
                // Clean the data before sending to remove any `undefined` values.
                const cleanedOddsData = cleanUndefined(gameOdds);
                await saveParsedOdds({ oddsData: cleanedOddsData });
                toast({ title: 'Success', description: `Successfully parsed and saved odds for ${away_team} vs ${home_team}.` });
                inputEl.value = '';
            } catch (error: any) {
                console.error("Error saving to Firestore: ", error);
                const errorMessage = error.message || 'An unknown error occurred.';
                toast({ title: 'Firestore Error', description: `Failed to save odds. Details: ${errorMessage}`, variant: 'destructive' });
            } finally {
                setLoading(false);
            }
        };
        
        (window as any).parseAndSave = parseAndSave;

    }, [toast]);

    return (
        <div className="space-y-6">
            <h1 className="text-3xl font-bold">Admin Odds Parser</h1>
            <Card>
                <CardHeader>
                    <CardTitle>Manual Odds Entry</CardTitle>
                    <CardDescription>
                        Paste raw text-based odds from a source. The tool will parse it and save it to Firestore to be displayed on the Live Odds page.
                    </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                    <Textarea 
                        id="propsInput"
                        className="min-h-[400px] font-mono"
                        placeholder="Paste the complete props data from your sportsbook here..."
                    />
                    <Button onClick={() => (window as any).parseAndSave()} disabled={loading}>
                        {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                        Parse and Save Odds
                    </Button>
                </CardContent>
            </Card>
        </div>
    );
};

export default OddsParserPage;
