// src/app/(main)/admin/ai-chat/page.tsx
'use client';

import { useState, useRef, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Loader2, Send, Sparkles, BrainCircuit } from 'lucide-react';
import { rajibChat, type RajibChatInput } from '@/ai/flows/rajib-chat-flow';
import { cn } from '@/lib/utils';

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
}

export default function AiChatPage() {
    const [messages, setMessages] = useState<Message[]>([]);
    const [input, setInput] = useState('');
    const [loading, setLoading] = useState(false);
    const scrollAreaRef = useRef<HTMLDivElement>(null);

    const scrollToBottom = () => {
        if (scrollAreaRef.current) {
            scrollAreaRef.current.scrollTo({
                top: scrollAreaRef.current.scrollHeight,
                behavior: 'smooth'
            });
        }
    };

    useEffect(() => {
        scrollToBottom();
    }, [messages]);

    const handleSendMessage = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!input.trim() || loading) return;

        const userMessage: Message = { 
            id: Date.now().toString(), 
            role: 'user', 
            content: input 
        };
        
        setMessages(prev => [...prev, userMessage]);
        const currentInput = input;
        setInput('');
        setLoading(true);

        // Convert message history to the format expected by the flow
        const history = messages.map(m => ({ 
            role: m.role === 'assistant' ? 'model' as const : 'user' as const, 
            content: m.content 
        }));

        try {
            const chatInput: RajibChatInput = {
                history,
                message: currentInput,
            };

            const stream = await rajibChat(chatInput);
            
            const assistantMessageId = (Date.now() + 1).toString();
            let fullResponse = '';

            // Add empty assistant message that will be updated
            setMessages(prev => [...prev, { 
                id: assistantMessageId, 
                role: 'assistant', 
                content: '' 
            }]);

            // Stream the response
            for await (const chunk of stream) {
                if (chunk) {
                    fullResponse += chunk;
                    setMessages(prev => prev.map(m => 
                        m.id === assistantMessageId 
                            ? { ...m, content: fullResponse } 
                            : m
                    ));
                }
            }
        } catch (error) {
            console.error('Chat error:', error);
            const errorId = (Date.now() + 2).toString();
            setMessages(prev => [...prev, { 
                id: errorId, 
                role: 'assistant', 
                content: 'Sorry, I encountered an error. Please try again.' 
            }]);
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="flex flex-col h-[calc(100vh-8rem)]">
            <h1 className="text-3xl font-bold flex items-center gap-2 mb-4">
                <BrainCircuit className="h-7 w-7 text-primary" />
                AI Chat with Rajib
            </h1>
            <Card className="flex-1 flex flex-col">
                <CardHeader>
                    <CardTitle>Rajib, MLB Analyst</CardTitle>
                    <CardDescription>Ask me anything about MLB data, analysis, and betting insights.</CardDescription>
                </CardHeader>
                <CardContent className="flex-1 flex flex-col gap-4 overflow-hidden">
                   <ScrollArea className="flex-1 pr-4" ref={scrollAreaRef}>
                        <div className="space-y-6">
                            {messages.length === 0 && (
                                <div className="flex items-center justify-center h-32 text-muted-foreground">
                                    <div className="text-center">
                                        <Sparkles className="h-8 w-8 mx-auto mb-2" />
                                        <p>Start a conversation with Rajib, your MLB expert!</p>
                                    </div>
                                </div>
                            )}
                            {messages.map((message) => (
                                <div key={message.id} className={cn(
                                    "flex items-start gap-4", 
                                    message.role === 'user' ? 'justify-end' : 'justify-start'
                                )}>
                                    {message.role === 'assistant' && (
                                        <Avatar className="h-9 w-9 border-2 border-primary">
                                            <AvatarFallback className="bg-primary text-primary-foreground">R</AvatarFallback>
                                        </Avatar>
                                    )}
                                    <div className={cn(
                                        "max-w-xl rounded-lg px-4 py-3", 
                                        message.role === 'user' 
                                            ? 'bg-primary text-primary-foreground' 
                                            : 'bg-secondary'
                                    )}>
                                        <p className="text-sm whitespace-pre-wrap">{message.content}</p>
                                    </div>
                                    {message.role === 'user' && (
                                        <Avatar className="h-9 w-9">
                                            <AvatarFallback>U</AvatarFallback>
                                        </Avatar>
                                    )}
                                </div>
                            ))}
                             {loading && (
                                <div className="flex items-start gap-4">
                                     <Avatar className="h-9 w-9 border-2 border-primary">
                                        <AvatarFallback className="bg-primary text-primary-foreground">R</AvatarFallback>
                                    </Avatar>
                                     <div className="max-w-xl rounded-lg px-4 py-3 bg-secondary flex items-center gap-2">
                                        <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
                                        <span className="text-sm text-muted-foreground">Rajib is thinking...</span>
                                    </div>
                                </div>
                            )}
                        </div>
                    </ScrollArea>
                    <form onSubmit={handleSendMessage} className="flex items-center gap-2 pt-4 border-t">
                        <Input
                            value={input}
                            onChange={(e) => setInput(e.target.value)}
                            placeholder="Ask Rajib about MLB stats, betting, or analysis..."
                            disabled={loading}
                            autoComplete="off"
                            className="flex-1"
                        />
                        <Button type="submit" disabled={loading || !input.trim()}>
                            {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
                            <span className="sr-only">Send</span>
                        </Button>
                    </form>
                </CardContent>
            </Card>
        </div>
    );
}