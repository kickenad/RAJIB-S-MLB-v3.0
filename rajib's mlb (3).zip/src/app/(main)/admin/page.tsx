'use client';

import { Card, CardHeader, CardTitle, CardContent, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import Link from 'next/link';
import { Webhook, DatabaseZap, BrainCircuit } from "lucide-react";

export default function AdminPage() {
  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold">Admin Dashboard</h1>
      <Card>
        <CardHeader>
          <CardTitle>Admin Tools</CardTitle>
          <CardDescription>
            Access various administrative tools to manage the application data and features.
          </CardDescription>
        </CardHeader>
        <CardContent className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Link href="/admin/odds-parser" passHref>
               <Button variant="outline" className="w-full h-20 flex flex-col gap-2">
                    <Webhook className="h-6 w-6" />
                    <span>Odds Parser</span>
                </Button>
            </Link>
             <Link href="/admin/firestore-test" passHref>
               <Button variant="outline" className="w-full h-20 flex flex-col gap-2">
                    <DatabaseZap className="h-6 w-6" />
                    <span>Firestore Test</span>
                </Button>
            </Link>
             <Link href="/admin/ai-chat" passHref>
               <Button variant="outline" className="w-full h-20 flex flex-col gap-2">
                    <BrainCircuit className="h-6 w-6" />
                    <span>AI Chat</span>
                </Button>
            </Link>
        </CardContent>
      </Card>
    </div>
  );
}
