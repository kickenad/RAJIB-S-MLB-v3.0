// src/app/(main)/admin/layout.tsx
'use client';
import { useAuth } from '@/hooks/useAuth';
import { useRouter } from 'next/navigation';
import { useEffect } from 'react';
import { Loader2, ShieldAlert } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';

export default function AdminLayout({ children }: { children: React.ReactNode }) {
    const { isAdmin, loading } = useAuth();
    const router = useRouter();

    // useEffect(() => {
    //     // Temporarily disabled to allow access for setup.
    //     // To re-enable, uncomment this block.
    //     if (!loading && !isAdmin) {
    //         router.replace('/dashboard');
    //     }
    // }, [isAdmin, loading, router]);

    // if (loading) {
    //     return (
    //          <div className="flex h-full w-full items-center justify-center bg-background">
    //             <Loader2 className="h-10 w-10 animate-spin text-primary" />
    //         </div>
    //     )
    // }

    // if (!isAdmin) {
    //      return (
    //         <div className="flex h-full w-full items-center justify-center">
    //            <Card className="w-full max-w-md">
    //                 <CardHeader>
    //                     <CardTitle className="flex items-center gap-2"><ShieldAlert className="text-destructive"/> Access Denied</CardTitle>
    //                     <CardDescription>You do not have permission to view this page.</CardDescription>
    //                 </CardHeader>
    //                 <CardContent>
    //                     <p>Please contact an administrator if you believe this is a mistake.</p>
    //                 </CardContent>
    //            </Card>
    //         </div>
    //     )
    // }

    return <>{children}</>;
}
