// src/app/(main)/admin/firestore-test/page.tsx
'use client';

import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { getFunctions, httpsCallable } from 'firebase/functions';
import { app } from '@/lib/firebase.config';
import { Loader2, CheckCircle, AlertCircle, DatabaseZap } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

const FirestoreTestPage: React.FC = () => {
    const [loading, setLoading] = useState(false);
    const [writeData, setWriteData] = useState('Hello Firestore!');
    const [readResult, setReadResult] = useState<string | null>(null);
    const [error, setError] = useState<string | null>(null);
    const { toast } = useToast();

    const handleWrite = async () => {
        setLoading(true);
        setError(null);
        setReadResult(null);
        try {
            const functions = getFunctions(app);
            const testFirestoreWrite = httpsCallable(functions, 'testFirestoreWrite');
            await testFirestoreWrite({ message: writeData });
            toast({
                title: 'Write Successful',
                description: `Successfully wrote "${writeData}" to Firestore.`,
            });
        } catch (error: any) {
            console.error("Firestore write error:", error);
            setError(error.message || 'An unknown error occurred during write.');
            toast({
                title: 'Write Failed',
                description: error.message,
                variant: 'destructive',
            });
        } finally {
            setLoading(false);
        }
    };

    const handleRead = async () => {
        setLoading(true);
        setError(null);
        setReadResult(null);
        try {
            const functions = getFunctions(app);
            const testFirestoreRead = httpsCallable(functions, 'testFirestoreRead');
            const result: any = await testFirestoreRead();
            const message = result.data.message;
            setReadResult(message);
             toast({
                title: 'Read Successful',
                description: `Successfully read "${message}" from Firestore.`,
            });
        } catch (error: any) {
            console.error("Firestore read error:", error);
            setError(error.message || 'An unknown error occurred during read.');
            toast({
                title: 'Read Failed',
                description: error.message,
                variant: 'destructive',
            });
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="space-y-6">
            <h1 className="text-3xl font-bold flex items-center gap-2">
                <DatabaseZap className="h-7 w-7 text-primary" />
                Firestore Connectivity Test
            </h1>
            <Card>
                <CardHeader>
                    <CardTitle>Direct Database Test</CardTitle>
                    <CardDescription>
                        Use these buttons to perform a direct write and read operation to your Firestore database. This helps verify that the connection and security rules are working correctly.
                    </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                    <div className="space-y-2">
                         <label htmlFor="test-data" className="font-medium text-sm">Data to write:</label>
                        <Input 
                            id="test-data"
                            value={writeData}
                            onChange={(e) => setWriteData(e.target.value)}
                            disabled={loading}
                        />
                    </div>
                    <div className="flex gap-4">
                        <Button onClick={handleWrite} disabled={loading} className="w-full">
                            {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                            1. Write to Firestore
                        </Button>
                        <Button onClick={handleRead} disabled={loading} className="w-full">
                             {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                            2. Read from Firestore
                        </Button>
                    </div>
                </CardContent>
            </Card>

            {error && (
                <Alert variant="destructive">
                    <AlertCircle className="h-4 w-4" />
                    <AlertTitle>Operation Failed</AlertTitle>
                    <AlertDescription>{error}</AlertDescription>
                </Alert>
            )}

            {readResult && (
                 <Alert variant="default" className="bg-green-500/10 border-green-500/30">
                    <CheckCircle className="h-4 w-4 text-green-400" />
                    <AlertTitle className="text-green-300">Read Result</AlertTitle>
                    <AlertDescription className="text-xl font-mono text-white">
                        {readResult}
                    </AlertDescription>
                </Alert>
            )}
        </div>
    );
};

export default FirestoreTestPage;
