// src/app/(main)/data-hub/player-stats/[playerId]/page.tsx
import { getPlayer } from '@/lib/mlb';
import { fetchBatterStats, fetchPitcherStats, type HittingStats, type PitcherStats } from '@/lib/mlb-stats';
import { notFound } from 'next/navigation';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { User, BarChart3, TrendingUp } from 'lucide-react';
import { unstable_noStore as noStore } from 'next/cache';

interface PageProps {
    params: { playerId: string }
}

const StatDisplay = ({ label, value }: { label: string, value: string | number | undefined }) => (
    <div className="flex justify-between items-center p-3 rounded-md bg-secondary/50">
        <span className="text-muted-foreground">{label}</span>
        <span className="font-mono font-bold text-foreground">{value ?? 'N/A'}</span>
    </div>
);

const HittingStatsGrid = ({ stats }: { stats: HittingStats }) => (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
        <StatDisplay label="Games Played" value={stats.gamesPlayed} />
        <StatDisplay label="At Bats" value={stats.atBats} />
        <StatDisplay label="Plate Appearances" value={stats.plateAppearances} />
        <StatDisplay label="Hits" value={stats.hits} />
        <StatDisplay label="Runs" value={stats.runs} />
        <StatDisplay label="RBIs" value={stats.rbi} />
        <StatDisplay label="Doubles" value={stats.doubles} />
        <StatDisplay label="Triples" value={stats.triples} />
        <StatDisplay label="Home Runs" value={stats.homeRuns} />
        <StatDisplay label="Walks" value={stats.baseOnBalls} />
        <StatDisplay label="Strikeouts" value={stats.strikeOuts} />
        <StatDisplay label="Stolen Bases" value={stats.stolenBases} />
        <StatDisplay label="Batting Average" value={stats.avg} />
        <StatDisplay label="On-Base %" value={stats.obp} />
        <StatDisplay label="Slugging %" value={stats.slg} />
        <StatDisplay label="OPS" value={stats.ops} />
    </div>
);

const PitchingStatsGrid = ({ stats }: { stats: PitcherStats }) => (
     <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
        <StatDisplay label="Wins" value={stats.wins} />
        <StatDisplay label="Losses" value={stats.losses} />
        <StatDisplay label="ERA" value={stats.era} />
        <StatDisplay label="WHIP" value={stats.whip} />
        <StatDisplay label="Innings Pitched" value={stats.inningsPitched} />
        <StatDisplay label="Strikeouts" value={stats.strikeouts} />
        <StatDisplay label="Walks" value={stats.baseOnBalls} />
        <StatDisplay label="K/BB Ratio" value={stats.strikeoutWalkRatio} />
        <StatDisplay label="K/9" value={stats.strikeoutsPer9Inn} />
        <StatDisplay label="H/9" value={stats.hitsPer9Inn} />
        <StatDisplay label="HR/9" value={stats.homeRunsPer9} />
    </div>
);


export default async function PlayerStatsPage({ params: { playerId: playerIdString } }: PageProps) {
    noStore();
    const playerId = parseInt(playerIdString, 10);
    if (isNaN(playerId)) {
        notFound();
    }
    
    const player = await getPlayer(playerId);
    if (!player) {
        notFound();
    }

    const [hittingStats, pitchingStats] = await Promise.all([
        fetchBatterStats(playerId),
        fetchPitcherStats(playerId)
    ]);

    return (
        <div className="space-y-6">
            <Card>
                <CardHeader>
                    <div className="flex items-center gap-4">
                        <Avatar className="h-20 w-20 border">
                             <AvatarImage src={`https://img.mlbstatic.com/mlb-photos/image/upload/d_people:generic_headshot.png/w_120,h_120,q_auto:best/v1/people/${player.id}/headshot/67/current`} alt={player.fullName} />
                             <AvatarFallback className="text-2xl">{player.fullName.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                        </Avatar>
                        <div>
                             <h1 className="text-3xl font-bold tracking-tight">{player.fullName}</h1>
                             <p className="text-muted-foreground text-lg">{player.primaryPosition?.name}</p>
                        </div>
                    </div>
                </CardHeader>
            </Card>
            
            {hittingStats && (
                <Card>
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                           <BarChart3 className="h-6 w-6" /> Hitting Stats
                        </CardTitle>
                        <CardDescription>Season hitting statistics for {player.fullName}.</CardDescription>
                    </CardHeader>
                    <CardContent>
                        <HittingStatsGrid stats={hittingStats} />
                    </CardContent>
                </Card>
            )}

            {pitchingStats && (
                 <Card>
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                           <TrendingUp className="h-6 w-6" /> Pitching Stats
                        </CardTitle>
                        <CardDescription>Season pitching statistics for {player.fullName}.</CardDescription>
                    </CardHeader>
                    <CardContent>
                        <PitchingStatsGrid stats={pitchingStats} />
                    </CardContent>
                </Card>
            )}

            {!hittingStats && !pitchingStats && (
                 <Card>
                    <CardContent className="p-16 flex flex-col items-center justify-center text-center">
                         <User className="h-16 w-16 text-muted-foreground mb-4" />
                        <h3 className="text-xl font-semibold">No Stats Found</h3>
                        <p className="text-muted-foreground max-w-md">No hitting or pitching statistics could be found for this player for the current season.</p>
                    </CardContent>
                </Card>
            )}

        </div>
    )
}
