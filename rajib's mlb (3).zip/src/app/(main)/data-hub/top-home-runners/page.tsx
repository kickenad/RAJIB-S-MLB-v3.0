// src/app/(main)/data-hub/top-home-runners/page.tsx
import { Card, CardHeader, CardTitle, CardContent, CardDescription } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Diamond } from "lucide-react";
import { fetchStatLeaders, type PlayerStatLeader } from '@/lib/mlb-stats';
import { unstable_noStore as noStore } from 'next/cache';

export default async function TopHomeRunnersPage() {
  noStore();
  const leaders: PlayerStatLeader[] = await fetchStatLeaders('homeRuns');

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
          <div>
              <h1 className="text-3xl font-bold tracking-tight flex items-center gap-2">
                  <Diamond className="h-7 w-7 text-primary" />
                  Top Home Run Hitters
              </h1>
              <p className="text-muted-foreground">
                  Season leaderboard for home runs across the league.
              </p>
          </div>
      </div>

      <Card>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
             <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-[80px]">Rank</TableHead>
                    <TableHead>Player</TableHead>
                    <TableHead>Team</TableHead>
                    <TableHead className="text-right">Home Runs</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {leaders.length > 0 ? leaders.map((player) => (
                    <TableRow key={player.person.id}>
                      <TableCell className="font-bold text-lg text-muted-foreground">{player.rank}</TableCell>
                      <TableCell>
                        <div className="flex items-center gap-3">
                           <Avatar>
                                <AvatarImage src={`https://img.mlbstatic.com/mlb-photos/image/upload/d_people:generic_headshot.png/w_120,h_120,q_auto:best/v1/people/${player.person.id}/headshot/67/current`} alt={player.person.fullName} />
                                <AvatarFallback>{player.person.fullName.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                            </Avatar>
                          <span className="font-medium">{player.person.fullName}</span>
                        </div>
                      </TableCell>
                      <TableCell>{player.team.name}</TableCell>
                      <TableCell className="text-right font-bold text-xl">{player.value}</TableCell>
                    </TableRow>
                  )) : (
                    <TableRow>
                      <TableCell colSpan={4} className="text-center h-24">
                        Could not load home run leaders.
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
