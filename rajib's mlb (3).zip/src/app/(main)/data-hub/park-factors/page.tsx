// src/app/(main)/data-hub/park-factors/page.tsx
import { Card, CardHeader, CardTitle, CardContent, CardDescription } from "@/components/ui/card";
import { List } from "lucide-react";
import { parkFactorsDB, type ParkFactorSet } from '@/lib/parkFactors';
import { ParkFactorInfoCard } from "@/components/mlb/park-factor-card-static";


export default function ParkFactorsPage() {
    const allParkFactors = Object.entries(parkFactorsDB).map(([venueName, factors]) => ({
        venueName,
        ...factors
    }));

    return (
        <div className="space-y-6">
            <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
                <div>
                    <h1 className="text-3xl font-bold tracking-tight flex items-center gap-2">
                         <List className="h-7 w-7 text-primary" />
                        Park Factors
                    </h1>
                    <p className="text-muted-foreground">Detailed data on how each park influences games.</p>
                </div>
            </div>
            <div className="grid gap-6 md:grid-cols-1 lg:grid-cols-2 xl:grid-cols-3">
                 {allParkFactors.map(data => (
                    <ParkFactorInfoCard key={data.venueName} data={data} />
                ))}
            </div>
        </div>
    );
}
