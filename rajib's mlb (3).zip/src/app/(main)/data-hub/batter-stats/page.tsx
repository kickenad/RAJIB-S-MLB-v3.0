
// src/app/(main)/data-hub/batter-stats/page.tsx
import { BarChart3 } from "lucide-react";
import { fetchAllPlayerHittingStats, type PlayerHittingStats } from "@/lib/mlb-stats";
import { PlayerStatsTable } from "@/components/mlb/player-stats-table";
import { HittingStatColumns } from "@/components/mlb/stats-columns";

export default async function BatterStatsPage() {
    const stats: PlayerHittingStats[] = await fetchAllPlayerHittingStats();

    return (
        <div className="space-y-6">
            <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
                <div>
                    <h1 className="text-3xl font-bold tracking-tight flex items-center gap-2">
                        <BarChart3 className="h-7 w-7 text-primary" />
                        Batter Stats Hub
                    </h1>
                    <p className="text-muted-foreground">
                        Comprehensive season statistics for all MLB batters.
                    </p>
                </div>
            </div>
            
            <PlayerStatsTable
                columns={HittingStatColumns}
                data={stats}
                searchColumn="playerName"
                searchPlaceholder="Filter by player name..."
            />
        </div>
    );
}
