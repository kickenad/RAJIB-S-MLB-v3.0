
// src/app/(main)/data-hub/pitcher-stats/page.tsx
import { BarChart3 } from "lucide-react";
import { fetchAllPlayerPitchingStats, type PlayerPitchingStats } from "@/lib/mlb-stats";
import { PlayerStatsTable } from "@/components/mlb/player-stats-table";
import { PitchingStatColumns } from "@/components/mlb/stats-columns";

export default async function PitcherStatsPage() {
    const stats: PlayerPitchingStats[] = await fetchAllPlayerPitchingStats();

    return (
        <div className="space-y-6">
            <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
                <div>
                    <h1 className="text-3xl font-bold tracking-tight flex items-center gap-2">
                        <BarChart3 className="h-7 w-7 text-primary" />
                        Pitcher Stats Hub
                    </h1>
                    <p className="text-muted-foreground">
                        Comprehensive season statistics for all MLB pitchers.
                    </p>
                </div>
            </div>
            
            <PlayerStatsTable
                columns={PitchingStatColumns}
                data={stats}
                searchColumn="playerName"
                searchPlaceholder="Filter by player name..."
            />
        </div>
    );
}
