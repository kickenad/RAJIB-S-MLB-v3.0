// src/app/(main)/data-hub/team-data/page.tsx
import { Card, CardHeader, CardTitle, CardContent, CardDescription } from "@/components/ui/card";
import { Database, Users } from "lucide-react";
import { getAllTeams, type MlbTeam } from '@/lib/mlb';
import Link from "next/link";
import { unstable_noStore as noStore } from 'next/cache';

const TeamCard = ({ team }: { team: MlbTeam }) => (
    <Link href={`/data-hub/team-data/${team.id}`}>
        <Card className="hover:border-primary hover:bg-secondary transition-colors">
            <CardHeader>
                <CardTitle className="flex items-center gap-2">
                    <Users className="h-5 w-5 text-primary" />
                    <span>{team.name}</span>
                </CardTitle>
                <CardDescription>
                    {team.league.name} / {team.division.name}
                </CardDescription>
            </CardHeader>
        </Card>
    </Link>
);

export default async function TeamDataPage() {
    noStore();
    const teams = await getAllTeams();

    return (
        <div className="space-y-6">
             <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
                <div>
                    <h1 className="text-3xl font-bold tracking-tight flex items-center gap-2">
                        <Database className="h-7 w-7 text-primary" />
                        Team Data Hub
                    </h1>
                    <p className="text-muted-foreground">
                        Explore detailed data and statistics for all MLB teams.
                    </p>
                </div>
            </div>

            {teams.length > 0 ? (
                 <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                    {teams.map(team => (
                        <TeamCard key={team.id} team={team} />
                    ))}
                </div>
            ) : (
                <Card>
                    <CardContent className="p-16 flex flex-col items-center justify-center text-center">
                         <Database className="h-16 w-16 text-muted-foreground mb-4" />
                        <h3 className="text-xl font-semibold">Could Not Load Teams</h3>
                        <p className="text-muted-foreground">There was an issue fetching team data from the MLB API.</p>
                    </CardContent>
                </Card>
            )}
        </div>
    );
}
