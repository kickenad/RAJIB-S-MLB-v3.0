// src/app/(main)/data-hub/team-data/[teamId]/page.tsx
import { getTeam, getTeamRoster, type MlbPlayer, type MlbTeamRoster } from "@/lib/mlb";
import { notFound } from "next/navigation";
import { Card, CardHeader, CardTitle, CardContent, CardDescription } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { unstable_noStore as noStore } from 'next/cache';
import Link from "next/link";

interface PageProps {
    params: { teamId: string }
}

export default async function TeamDetailPage({ params: { teamId: teamIdString } }: PageProps) {
    noStore();
    const teamId = parseInt(teamIdString, 10);
    if (isNaN(teamId)) {
        notFound();
    }
    
    const team = await getTeam(teamId);
    if (!team) {
        notFound();
    }

    const roster = await getTeamRoster(teamId);

    return (
        <div className="space-y-6">
             <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
                <div>
                    <h1 className="text-3xl font-bold tracking-tight">{team.name}</h1>
                    <p className="text-muted-foreground">Active Roster</p>
                </div>
            </div>

            <Card>
                <CardHeader>
                    <CardTitle>Active Roster</CardTitle>
                    <CardDescription>Players currently on the active roster for the {team.name}.</CardDescription>
                </CardHeader>
                <CardContent>
                    <Table>
                        <TableHeader>
                            <TableRow>
                                <TableHead>Player</TableHead>
                                <TableHead>Position</TableHead>
                                <TableHead>Jersey #</TableHead>
                            </TableRow>
                        </TableHeader>
                        <TableBody>
                            {roster.map(item => (
                                <TableRow key={item.person.id}>
                                    <TableCell>
                                        <div className="flex items-center gap-3">
                                            <Avatar>
                                                <AvatarImage src={`https://img.mlbstatic.com/mlb-photos/image/upload/d_people:generic_headshot.png/w_120,h_120,q_auto:best/v1/people/${item.person.id}/headshot/67/current`} alt={item.person.fullName} />
                                                <AvatarFallback>{item.person.fullName.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                                            </Avatar>
                                            <Link href={`/data-hub/player-stats/${item.person.id}`} className="font-medium hover:underline">
                                                {item.person.fullName}
                                            </Link>
                                        </div>
                                    </TableCell>
                                    <TableCell>{item.position.name}</TableCell>
                                    <TableCell>{item.jerseyNumber}</TableCell>
                                </TableRow>
                            ))}
                        </TableBody>
                    </Table>
                </CardContent>
            </Card>

        </div>
    )
}
