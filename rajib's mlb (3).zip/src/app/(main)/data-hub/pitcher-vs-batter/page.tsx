// src/app/(main)/data-hub/pitcher-vs-batter/page.tsx
'use client';

import { useState } from 'react';
import { Card, CardHeader, CardTitle, CardContent, CardDescription } from "@/components/ui/card";
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { BarChart3, Loader2, Search, User, AlertTriangle } from "lucide-react";
import type { PlayerVsPlayerStats } from '@/lib/mlb-stats';

export default function PitcherVsBatterPage() {
  const [batterName, setBatterName] = useState('');
  const [pitcherName, setPitcherName] = useState('');
  const [stats, setStats] = useState<PlayerVsPlayerStats | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSearch = async () => {
    if (!batterName || !pitcherName) {
      setError('Please enter both a batter and a pitcher name.');
      return;
    }
    setLoading(true);
    setError(null);
    setStats(null);

    try {
      const response = await fetch(`/api/pbp-stats?batterName=${encodeURIComponent(batterName)}&pitcherName=${encodeURIComponent(pitcherName)}`);
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.detail || 'Failed to fetch data.');
      }
      const data = await response.json();
      setStats(data);
    } catch (e: any) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold">Pitcher Vs Batter H2H</h1>
      
      <Card>
        <CardHeader>
          <CardTitle>Matchup Analysis</CardTitle>
          <CardDescription>Enter player names to see their historical head-to-head performance.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-end">
            <div className="space-y-2">
              <label htmlFor="batter" className="font-medium">Batter Name</label>
              <Input id="batter" placeholder="e.g., Aaron Judge" value={batterName} onChange={e => setBatterName(e.target.value)} />
            </div>
            <div className="space-y-2">
              <label htmlFor="pitcher" className="font-medium">Pitcher Name</label>
              <Input id="pitcher" placeholder="e.g., Gerrit Cole" value={pitcherName} onChange={e => setPitcherName(e.target.value)} />
            </div>
            <Button onClick={handleSearch} disabled={loading}>
              {loading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Search className="mr-2 h-4 w-4" />}
              Search Matchup
            </Button>
          </div>
        </CardContent>
      </Card>
      
      {error && (
        <Card className="border-destructive">
            <CardHeader className="flex-row items-center gap-4">
                 <AlertTriangle className="h-8 w-8 text-destructive" />
                <div>
                    <CardTitle className="text-destructive">An Error Occurred</CardTitle>
                    <CardDescription>{error}</CardDescription>
                </div>
            </CardHeader>
        </Card>
      )}

      {loading && (
        <div className="flex justify-center items-center py-16">
          <Loader2 className="h-10 w-10 animate-spin text-primary" />
        </div>
      )}

      {stats && (
        <Card>
          <CardHeader>
            <CardTitle>{stats.batter?.fullName} vs. {stats.pitcher?.fullName}</CardTitle>
            <CardDescription>Career head-to-head statistics.</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>PA</TableHead>
                    <TableHead>AB</TableHead>
                    <TableHead>H</TableHead>
                    <TableHead>2B</TableHead>
                    <TableHead>3B</TableHead>
                    <TableHead>HR</TableHead>
                    <TableHead>RBI</TableHead>
                    <TableHead>BB</TableHead>
                    <TableHead>SO</TableHead>
                    <TableHead>AVG</TableHead>
                    <TableHead>OBP</TableHead>
                    <TableHead>SLG</TableHead>
                    <TableHead>OPS</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  <TableRow>
                    <TableCell>{stats.plateAppearances}</TableCell>
                    <TableCell>{stats.atBats}</TableCell>
                    <TableCell>{stats.hits}</TableCell>
                    <TableCell>{stats.doubles}</TableCell>
                    <TableCell>{stats.triples}</TableCell>
                    <TableCell>{stats.homeRuns}</TableCell>
                    <TableCell>{stats.rbi}</TableCell>
                    <TableCell>{stats.baseOnBalls}</TableCell>
                    <TableCell>{stats.strikeOuts}</TableCell>
                    <TableCell>{stats.avg}</TableCell>
                    <TableCell>{stats.obp}</TableCell>
                    <TableCell>{stats.slg}</TableCell>
                    <TableCell>{stats.ops}</TableCell>
                  </TableRow>
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      )}

      {!stats && !loading && !error && (
         <div className="flex flex-col items-center justify-center text-center py-16 text-muted-foreground">
            <BarChart3 className="h-12 w-12 mb-4" />
            <h3 className="text-xl font-semibold text-foreground">Awaiting Search</h3>
            <p>Enter a batter and pitcher to see their matchup data.</p>
          </div>
      )}
    </div>
  );
}
