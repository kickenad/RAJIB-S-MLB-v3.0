// src/app/(main)/schedule/daily-schedule/page.tsx
'use client';

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import {
    Calendar as CalendarIcon,
    RefreshCw,
    Loader2,
    Clock,
    MapPin,
    Thermometer,
    Users,
    BrainCircuit,
    Wind,
    CloudRain
} from 'lucide-react';
import { getGamesForDate, type MlbGame } from '@/lib/mlb';
import { format } from 'date-fns';
import { toZonedTime, format as formatTz } from 'date-fns-tz';
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Calendar } from "@/components/ui/calendar"
import { cn } from "@/lib/utils"
import { stadiumCoordinates } from '@/lib/stadiumCoordinates';
import axios from 'axios';
import { Separator } from '@/components/ui/separator';
import Link from 'next/link';

interface GameWeather {
    temperature?: number;
    windspeed?: number;
    precipitation?: number;
}

interface EnrichedMlbGame extends MlbGame {
    weatherData?: GameWeather;
}

const fetchWeather = async (lat: number, lon: number, gameTimeUTC: string): Promise<GameWeather | null> => {
    try {
        const targetHour = formatTz(toZonedTime(gameTimeUTC, 'America/New_York'), 'yyyy-MM-dd\'T\'HH:00');
        const url = `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&hourly=temperature_2m,precipitation,windspeed_10m&temperature_unit=fahrenheit&wind_speed_unit=mph&precipitation_unit=inch&timezone=America%2FNew_York`;

        const res = await axios.get(url);
        const data = res.data;
        const index = data.hourly.time.findIndex((t: string) => t.startsWith(targetHour));

        if (index === -1) return null;

        return {
            temperature: data.hourly.temperature_2m[index],
            precipitation: data.hourly.precipitation[index],
            windspeed: data.hourly.windspeed_10m[index],
        };
    } catch (error) {
        console.error("Error fetching weather data", error);
        return null;
    }
};


function GameCard({ game }: { game: EnrichedMlbGame }) {
    const gameTimeET = toZonedTime(game.gameDate, 'America/New_York');
    const gameTime = formatTz(gameTimeET, 'p', { timeZone: 'America/New_York' });

    const statusColor: { [key: string]: string } = {
        'Scheduled': 'bg-blue-200 text-blue-800 dark:bg-blue-900/50 dark:text-blue-300',
        'Pre-Game': 'bg-blue-200 text-blue-800 dark:bg-blue-900/50 dark:text-blue-300',
        'In Progress': 'bg-yellow-200 text-yellow-800 dark:bg-yellow-900/50 dark:text-yellow-300',
        'Final': 'bg-green-200 text-green-800 dark:bg-green-900/50 dark:text-green-300',
        'Postponed': 'bg-red-200 text-red-800 dark:bg-red-900/50 dark:text-red-300',
        'Game Over': 'bg-green-200 text-green-800 dark:bg-green-900/50 dark:text-green-300',
    };
    const detailedStatus = game.status?.detailedState ?? 'Unknown';
    const showScore = detailedStatus !== 'Scheduled' && detailedStatus !== 'Pre-Game' && detailedStatus !== 'Postponed';

    return (
        <Card className="w-full max-w-md mx-auto bg-card/50 border-border/50">
            <CardContent className="p-6 space-y-4">
                <div className="flex justify-between items-start">
                    <div>
                        <h2 className="text-xl font-bold">{game.teams.away.team.name}</h2>
                        <h2 className="text-xl font-bold">@ {game.teams.home.team.name}</h2>
                    </div>
                    <div className={cn(
                        "px-2 py-1 text-xs rounded-md font-semibold text-right",
                        statusColor[detailedStatus] || 'bg-gray-200 text-gray-800 dark:bg-gray-700 dark:text-gray-300'
                    )}>
                        {detailedStatus}
                    </div>
                </div>

                {showScore && (
                    <div className="text-center text-2xl font-bold tracking-wider space-x-4 py-2 bg-secondary/30 rounded-lg">
                        <span>{game.linescore?.teams.away.runs ?? 0}</span>
                        <span className="text-muted-foreground">-</span>
                        <span>{game.linescore?.teams.home.runs ?? 0}</span>
                    </div>
                )}
                
                <Separator />
                
                <div className="space-y-4 text-sm text-muted-foreground">
                    <div className="flex items-center gap-2">
                        <Clock className="h-4 w-4" />
                        <span>{gameTime}</span>
                    </div>
                    <div className="flex items-center gap-2">
                        <MapPin className="h-4 w-4" />
                        <span>{game.venue.name}</span>
                    </div>
                </div>
                
                <div className="grid grid-cols-2 gap-4 text-center">
                    <div className="bg-secondary/50 p-3 rounded-lg">
                        <p className="font-semibold truncate">{game.teams.away.probablePitcher?.fullName ?? 'TBD'}</p>
                        <p className="text-xs text-muted-foreground">Away Pitcher</p>
                    </div>
                    <div className="bg-secondary/50 p-3 rounded-lg">
                        <p className="font-semibold truncate">{game.teams.home.probablePitcher?.fullName ?? 'TBD'}</p>
                        <p className="text-xs text-muted-foreground">Home Pitcher</p>
                    </div>
                </div>
                <div className="grid grid-cols-3 gap-4 text-center">
                    <div className="bg-secondary/50 p-3 rounded-lg">
                        <p className="text-sm text-muted-foreground flex items-center justify-center gap-1"><Thermometer className="h-4 w-4" /> Temp</p>
                        <p className="font-semibold">{game.weatherData?.temperature ? `${Math.round(game.weatherData.temperature)}°F` : 'N/A'}</p>
                    </div>
                    <div className="bg-secondary/50 p-3 rounded-lg">
                        <p className="text-sm text-muted-foreground flex items-center justify-center gap-1"><Wind className="h-4 w-4" /> Wind</p>
                        <p className="font-semibold">{game.weatherData?.windspeed ? `${Math.round(game.weatherData.windspeed)} mph` : 'N/A'}</p>
                    </div>
                    <div className="bg-secondary/50 p-3 rounded-lg">
                        <p className="text-sm text-muted-foreground flex items-center justify-center gap-1"><CloudRain className="h-4 w-4" /> Precip</p>
                        <p className="font-semibold">{game.weatherData?.precipitation ? `${game.weatherData.precipitation.toFixed(2)} in` : '0 in'}</p>
                    </div>
                </div>
                <Button asChild className="w-full bg-accent text-accent-foreground hover:bg-accent/90">
                    <Link href={`/picks/signal-analysis?gameId=${game.gamePk}`}>
                        <BrainCircuit className="mr-2 h-4 w-4" />
                        Generate AI Analysis
                    </Link>
                </Button>
            </CardContent>
        </Card>
    );
}

function ScheduleList({ games }: { games: EnrichedMlbGame[] }) {
    if (games.length === 0) {
        return <p className="text-center text-muted-foreground pt-16">No games scheduled for this date.</p>;
    }

    return (
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {games.map(game => (
                <GameCard key={game.gamePk} game={game} />
            ))}
        </div>
    );
}

function ScheduleSkeleton() {
    return (
        <div className="flex flex-col items-center gap-4 text-muted-foreground pt-16">
            <Loader2 className="h-10 w-10 animate-spin text-accent" />
            <p className="font-medium">Loading schedule for today...</p>
        </div>
    )
}

export default function SchedulePage() {
    const [date, setDate] = useState<Date | undefined>(new Date());
    const [games, setGames] = useState<EnrichedMlbGame[]>([]);
    const [loading, setLoading] = useState(true);

    const loadData = async (selectedDate: Date) => {
        setLoading(true);
        const gamesForDate = await getGamesForDate(format(selectedDate, 'yyyy-MM-dd'));
        
        const onlyScheduledGames = gamesForDate.filter(
          game => game.status.abstractGameState === 'Preview'
        );

        const enrichedGames: EnrichedMlbGame[] = [];
        for (const game of onlyScheduledGames) {
            const venueName = game.venue?.name;
            let weatherData = null;

            const gameStatus = game.status.detailedState;
            const shouldFetchWeather = gameStatus === 'Scheduled' || gameStatus === 'Pre-Game';

            if (venueName && shouldFetchWeather) {
                const normalizedVenueName = venueName === "Angel Stadium of Anaheim" ? "Angel Stadium" : venueName;

                const coords = stadiumCoordinates[normalizedVenueName];
                if (coords) {
                    await new Promise(resolve => setTimeout(resolve, 1000));
                    weatherData = await fetchWeather(coords.lat, coords.lon, game.gameDate);
                }
            }
            enrichedGames.push({ ...game, weatherData });
        }
        
        setGames(enrichedGames);
        setLoading(false);
    }

    useEffect(() => {
        if (date) {
            loadData(date);
        }
    }, [date]);

    return (
        <div className="space-y-6">
            <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
                <div className="flex items-center gap-3">
                    <div>
                        <h1 className="text-3xl font-bold tracking-tight">Game Schedule</h1>
                        <p className="text-muted-foreground">Upcoming games for the selected date.</p>
                    </div>
                </div>
                <div className="flex flex-col sm:flex-row flex-wrap shrink-0 gap-2">
                    <Popover>
                        <PopoverTrigger asChild>
                            <Button
                                variant={"outline"}
                                className={cn(
                                    "w-full sm:w-[280px] justify-start text-left font-normal",
                                    !date && "text-muted-foreground"
                                )}
                            >
                                <CalendarIcon className="mr-2 h-4 w-4" />
                                {date ? format(date, "PPP") : <span>Pick a date</span>}
                            </Button>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0">
                            <Calendar
                                mode="single"
                                selected={date}
                                onSelect={setDate}
                                initialFocus
                            />
                        </PopoverContent>
                    </Popover>
                    <Button variant="outline" onClick={() => {if(date) loadData(date)}}>
                        <RefreshCw className="mr-2 h-4 w-4" />
                        Refresh
                    </Button>
                </div>
            </div>

            <div className="min-h-[400px]">
                {loading ? <ScheduleSkeleton /> : <ScheduleList games={games} />}
            </div>
        </div>
    );
}