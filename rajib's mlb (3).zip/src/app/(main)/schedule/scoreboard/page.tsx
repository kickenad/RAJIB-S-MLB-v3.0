
'use client';

import React, { useState, useEffect, useCallback } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Loader2, RefreshCw, Tv, Gamepad2 } from 'lucide-react';
import { getGamesForDate, type MlbGame } from '@/lib/mlb';
import { format, isToday } from 'date-fns';
import { toZonedTime, format as formatTz } from 'date-fns-tz';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';

interface Linescore {
    currentInning: number;
    currentInningOrdinal: string;
    inningState: string;
    inningHalf: string;
    isTopInning: boolean;
    scheduledInnings: number;
    innings: { num: number; home: { runs?: number }; away: { runs?: number } }[];
    teams: {
        home: { runs?: number; hits?: number; errors?: number; };
        away: { runs?: number; hits?: number; errors?: number; };
    };
    defense: {
        pitcher?: { fullName: string };
        batter?: { fullName: string };
        onDeck?: { fullName: string };
        inHole?: { fullName: string };
    };
    offense: {
        batter?: { fullName: string };
        onDeck?: { fullName: string };
        inHole?: { fullName: string };
    };
    balls: number;
    strikes: number;
    outs: number;
}

interface EnrichedGame extends MlbGame {
    linescore?: Linescore;
}

const fetchGames = async (): Promise<EnrichedGame[]> => {
    const todayStr = format(new Date(), 'yyyy-MM-dd');
    const games = await getGamesForDate(todayStr);
    return games;
};

const getInningSuffix = (inning: number) => {
    if (inning >= 11 && inning <= 13) return 'th';
    switch (inning % 10) {
        case 1: return 'st';
        case 2: return 'nd';
        case 3: return 'rd';
        default: return 'th';
    }
};


function ScoreboardCard({ game }: { game: EnrichedGame }) {
    const { linescore, status, teams, venue, gameDate } = game;
    const gameTimeET = toZonedTime(gameDate, 'America/New_York');

    const renderGameStatus = () => {
        const detailedState = status.detailedState;
        if (detailedState === 'In Progress') {
            return (
                <div className="text-center text-sm">
                    <p className="font-semibold text-primary">{linescore?.inningHalf} {linescore?.currentInningOrdinal}</p>
                    <p className="text-muted-foreground">{linescore?.balls}-{linescore?.strikes}, {linescore?.outs} Out</p>
                </div>
            )
        }
        if (detailedState === "Final" || detailedState === "Game Over") {
            return <p className="font-bold text-green-400">Final</p>
        }
        if (detailedState === "Scheduled" || detailedState === "Pre-Game") {
             return <p className="font-semibold">{formatTz(gameTimeET, 'p', { timeZone: 'America/New_York' })} ET</p>
        }
        return <p className="font-semibold">{detailedState}</p>;
    }
    
    const inningHeaders = Array.from({ length: linescore?.scheduledInnings || 9 }, (_, i) => i + 1);

    return (
        <Card>
            <CardHeader>
                <CardTitle className="text-lg">{teams.away.team.name} @ {teams.home.team.name}</CardTitle>
                <CardDescription>{venue.name}</CardDescription>
            </CardHeader>
            <CardContent>
                <div className="grid grid-cols-3 items-center mb-4">
                    <div className="text-center">
                        <p className="text-3xl font-bold">{linescore?.teams.away.runs ?? 0}</p>
                        <p className="text-sm text-muted-foreground">Away</p>
                    </div>
                    <div className="text-center text-sm font-medium">
                        {renderGameStatus()}
                    </div>
                    <div className="text-center">
                         <p className="text-3xl font-bold">{linescore?.teams.home.runs ?? 0}</p>
                         <p className="text-sm text-muted-foreground">Home</p>
                    </div>
                </div>

                <div className="overflow-x-auto">
                    <Table>
                        <TableHeader>
                            <TableRow>
                                <TableHead className="w-[80px]">Team</TableHead>
                                {inningHeaders.map(inning => <TableHead key={inning} className="text-center">{inning}</TableHead>)}
                                <TableHead className="text-center font-bold text-foreground">R</TableHead>
                                <TableHead className="text-center font-bold text-foreground">H</TableHead>
                                <TableHead className="text-center font-bold text-foreground">E</TableHead>
                            </TableRow>
                        </TableHeader>
                        <TableBody>
                            <TableRow>
                                <TableCell className="font-semibold">{teams.away.team.name}</TableCell>
                                {inningHeaders.map(inningNum => (
                                    <TableCell key={inningNum} className="text-center">
                                        {linescore?.innings.find(i => i.num === inningNum)?.away.runs ?? ( (status.detailedState !== "Scheduled" && status.detailedState !== "Pre-Game" && (linescore?.currentInning ?? 0) >= inningNum) ? 0 : '-')}
                                    </TableCell>
                                ))}
                                <TableCell className="text-center font-bold">{linescore?.teams.away.runs ?? 0}</TableCell>
                                <TableCell className="text-center font-bold">{linescore?.teams.away.hits ?? 0}</TableCell>
                                <TableCell className="text-center font-bold">{linescore?.teams.away.errors ?? 0}</TableCell>
                            </TableRow>
                             <TableRow>
                                <TableCell className="font-semibold">{teams.home.team.name}</TableCell>
                                {inningHeaders.map(inningNum => (
                                    <TableCell key={inningNum} className="text-center">
                                         {linescore?.innings.find(i => i.num === inningNum)?.home.runs ?? ( (status.detailedState !== "Scheduled" && status.detailedState !== "Pre-Game" && (linescore?.currentInning ?? 0) >= inningNum) ? 0 : '-')}
                                    </TableCell>
                                ))}
                                <TableCell className="text-center font-bold">{linescore?.teams.home.runs ?? 0}</TableCell>
                                <TableCell className="text-center font-bold">{linescore?.teams.home.hits ?? 0}</TableCell>
                                <TableCell className="text-center font-bold">{linescore?.teams.home.errors ?? 0}</TableCell>
                            </TableRow>
                        </TableBody>
                    </Table>
                </div>
            </CardContent>
        </Card>
    );
}

export default function ScoreboardPage() {
    const [games, setGames] = useState<EnrichedGame[]>([]);
    const [loading, setLoading] = useState(true);
    const [lastUpdated, setLastUpdated] = useState<Date | null>(null);

    const loadGames = useCallback(async () => {
        setLoading(true);
        try {
            const gameData = await fetchGames();
            setGames(gameData);
            setLastUpdated(new Date());
        } catch (error) {
            console.error("Failed to fetch scoreboard data:", error);
        } finally {
            setLoading(false);
        }
    }, []);

    useEffect(() => {
        loadGames();
        const interval = setInterval(loadGames, 15000); // Refresh every 15 seconds
        return () => clearInterval(interval);
    }, [loadGames]);

    return (
        <div className="space-y-6">
            <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
                <div>
                    <h1 className="text-3xl font-bold tracking-tight flex items-center gap-2">
                        <Tv className="h-7 w-7 text-primary" />
                        Live Scoreboard
                    </h1>
                    <p className="text-muted-foreground">Real-time scores and updates for all ongoing MLB games.</p>
                </div>
                <div className='flex items-center gap-2'>
                    {lastUpdated && 
                        <p className="text-sm text-muted-foreground hidden sm:block">
                            Last Updated: {format(lastUpdated, 'p')}
                        </p>
                    }
                    <Button variant="outline" onClick={loadGames} disabled={loading}>
                        <RefreshCw className={cn("mr-2 h-4 w-4", loading && "animate-spin")} />
                        Refresh
                    </Button>
                </div>
            </div>

            {loading && games.length === 0 ? (
                 <div className="flex flex-col items-center justify-center text-center py-16 text-muted-foreground">
                    <Loader2 className="h-12 w-12 mb-4 animate-spin" />
                    <h3 className="text-xl font-semibold text-foreground">Loading Today's Games...</h3>
                </div>
            ) : games.length === 0 ? (
                <div className="flex flex-col items-center justify-center text-center py-16 text-muted-foreground">
                    <Gamepad2 className="h-12 w-12 mb-4" />
                    <h3 className="text-xl font-semibold text-foreground">No Games Today</h3>
                    <p>There are no games scheduled for today. Check back on the next game day!</p>
                </div>
            ) : (
                <div className="grid gap-6 md:grid-cols-1 lg:grid-cols-2">
                    {games.map(game => (
                        <ScoreboardCard key={game.gamePk} game={game} />
                    ))}
                </div>
            )}
        </div>
    );
}
