
'use client';

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { RefreshCw, Loader2, Thermometer, Wind, CloudRain, MapPin } from 'lucide-react';
import { stadiumCoordinates } from '@/lib/stadiumCoordinates';
import axios from 'axios';
import { format } from 'date-fns';
import { toZonedTime, format as formatTz } from 'date-fns-tz';
import { cn } from '@/lib/utils';

interface HourlyWeather {
  time: string[];
  temperature_2m: number[];
  precipitation: number[];
  windspeed_10m: number[];
}

interface StadiumWeatherData {
  name: string;
  hourly: HourlyWeather;
  currentHourIndex: number;
}

const fetchWeatherForStadium = async (lat: number, lon: number): Promise<Omit<StadiumWeatherData, 'name'> | null> => {
  try {
    const url = `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&hourly=temperature_2m,precipitation,windspeed_10m&temperature_unit=fahrenheit&wind_speed_unit=mph&precipitation_unit=inch&timezone=America%2FNew_York`;
    const res = await axios.get(url);
    const data = res.data;
    const nowET = toZonedTime(new Date(), 'America/New_York');
    const currentHourString = formatTz(nowET, "yyyy-MM-dd'T'HH:00");
    const currentHourIndex = data.hourly.time.findIndex((t: string) => t === currentHourString);

    return {
      hourly: data.hourly,
      currentHourIndex: currentHourIndex > -1 ? currentHourIndex : 0,
    };
  } catch (error) {
    console.error("Error fetching weather data for stadium", error);
    return null;
  }
};

function WeatherCard({ stadium }: { stadium: StadiumWeatherData }) {
  const { name, hourly, currentHourIndex } = stadium;
  const now = new Date();
  
  const relevantHours = hourly.time.slice(currentHourIndex, currentHourIndex + 6).map((t, i) => {
      const hourIndex = currentHourIndex + i;
      return {
          time: format(new Date(t), 'ha'),
          temp: hourly.temperature_2m[hourIndex],
          wind: hourly.windspeed_10m[hourIndex],
          precip: hourly.precipitation[hourIndex],
      }
  });

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
            <MapPin className="h-5 w-5 text-primary"/>
            {name}
        </CardTitle>
        <CardDescription>
            Last updated: {format(now, 'p')} ET
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-3 gap-2 text-center mb-4">
             <div className="bg-secondary/50 p-3 rounded-lg">
                <p className="text-sm text-muted-foreground flex items-center justify-center gap-1"><Thermometer className="h-4 w-4" /> Temp</p>
                <p className="font-semibold">{Math.round(hourly.temperature_2m[currentHourIndex])}°F</p>
            </div>
             <div className="bg-secondary/50 p-3 rounded-lg">
                <p className="text-sm text-muted-foreground flex items-center justify-center gap-1"><Wind className="h-4 w-4" /> Wind</p>
                <p className="font-semibold">{Math.round(hourly.windspeed_10m[currentHourIndex])} mph</p>
            </div>
            <div className="bg-secondary/50 p-3 rounded-lg">
                <p className="text-sm text-muted-foreground flex items-center justify-center gap-1"><CloudRain className="h-4 w-4" /> Precip</p>
                 <p className="font-semibold">{hourly.precipitation[currentHourIndex].toFixed(2)} in</p>
            </div>
        </div>
        <div className="space-y-2">
            <h4 className="font-semibold text-sm text-muted-foreground">Hourly Forecast</h4>
            <div className="grid grid-cols-3 md:grid-cols-6 gap-2 text-center">
                {relevantHours.map((hour, index) => (
                    <div key={index} className="bg-secondary/30 rounded-md p-2 text-xs">
                        <p className="font-bold">{hour.time}</p>
                        <p>{Math.round(hour.temp)}°</p>
                        <p className="text-muted-foreground">{Math.round(hour.wind)}mph</p>
                    </div>
                ))}
            </div>
        </div>
      </CardContent>
    </Card>
  );
}


function WeatherSkeleton() {
    return (
        <div className="flex flex-col items-center gap-4 text-muted-foreground pt-16">
            <Loader2 className="h-10 w-10 animate-spin text-accent" />
            <p className="font-medium">Fetching live weather data for all stadiums...</p>
        </div>
    )
}

export default function WeatherAnalysisPage() {
    const [stadiumWeather, setStadiumWeather] = useState<StadiumWeatherData[]>([]);
    const [loading, setLoading] = useState(true);
    const [lastUpdated, setLastUpdated] = useState(new Date());

    const loadWeatherData = async () => {
        setLoading(true);
        const allWeatherData: StadiumWeatherData[] = [];
        const stadiumEntries = Object.entries(stadiumCoordinates);

        const promises = stadiumEntries.map(async ([name, coords]) => {
            const weatherData = await fetchWeatherForStadium(coords.lat, coords.lon);
            if (weatherData) {
                return { name, ...weatherData };
            }
            return null;
        });

        const results = await Promise.all(promises);
        const filteredResults = results.filter(r => r !== null) as StadiumWeatherData[];
        
        setStadiumWeather(filteredResults);
        setLastUpdated(new Date());
        setLoading(false);
    }

    useEffect(() => {
        loadWeatherData();
        const interval = setInterval(loadWeatherData, 60 * 60 * 1000); // Auto-refresh every hour
        return () => clearInterval(interval);
    }, []);

  return (
    <div className="space-y-6">
       <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
            <div>
                <h1 className="text-3xl font-bold">Weather Analysis</h1>
                <p className="text-muted-foreground">Live weather conditions at every MLB stadium.</p>
            </div>
            <div className='flex items-center gap-2'>
                <p className="text-sm text-muted-foreground hidden sm:block">
                    Last Updated: {format(lastUpdated, 'p')} ET
                </p>
                <Button variant="outline" onClick={loadWeatherData} disabled={loading}>
                    <RefreshCw className={cn("mr-2 h-4 w-4", loading && "animate-spin")} />
                    Refresh
                </Button>
            </div>
        </div>

        {loading && stadiumWeather.length === 0 ? (
            <WeatherSkeleton />
        ) : (
             <div className="grid gap-6 md:grid-cols-2 xl:grid-cols-3">
                {stadiumWeather.map(stadium => (
                    <WeatherCard key={stadium.name} stadium={stadium} />
                ))}
            </div>
        )}

    </div>
  );
}
