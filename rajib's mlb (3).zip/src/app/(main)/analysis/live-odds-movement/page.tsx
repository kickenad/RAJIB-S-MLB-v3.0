import React, { useState, useEffect } from 'react';
import { RefreshCw, TrendingUp, Clock, AlertCircle } from 'lucide-react';

// Type definitions
interface GameOdds {
  awayTeam: string;
  homeTeam: string;
  gameTime: string;
  odds: {
    away: string;
    home: string;
  };
  scrapedAt: string;
}

interface LineMovement {
  time: string;
  spread: string;
  total: string;
}

interface ApiResponse {
  success: boolean;
  games?: GameOdds[];
  lineMovement?: LineMovement[];
  timestamp: string;
  error?: string;
}

const MLBOddsDashboard: React.FC = () => {
  const [oddsData, setOddsData] = useState<GameOdds[]>([]);
  const [lineMovement, setLineMovement] = useState<LineMovement[]>([]);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [lastUpdated, setLastUpdated] = useState<Date | null>(null);

  const fetchOdds = async (): Promise<void> => {
    setLoading(true);
    setError(null);
    
    try {
      console.log('Fetching odds from /api/scrape-odds...');
      
      const response = await fetch('/api/scrape-odds', {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
        },
      });

      console.log('Response status:', response.status);
      
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const contentType = response.headers.get('content-type');
      if (!contentType?.includes('application/json')) {
        const text = await response.text();
        console.error('Non-JSON response:', text);
        throw new Error('Server returned non-JSON response');
      }

      const data: ApiResponse = await response.json();
      console.log('Received data:', data);
      
      if (data.success) {
        setOddsData(data.games || []);
        setLineMovement(data.lineMovement || []);
        setLastUpdated(new Date(data.timestamp));
      } else {
        setError(data.error || 'Failed to fetch odds data');
      }
    } catch (err) {
      console.error('Fetch error:', err);
      setError('Network error: ' + (err instanceof Error ? err.message : 'Unknown error'));
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchOdds();
    // Auto-refresh every 5 minutes
    const interval = setInterval(fetchOdds, 5 * 60 * 1000);
    return () => clearInterval(interval);
  }, []);

  const formatTime = (timeString: string): string => {
    try {
      return new Date(timeString).toLocaleTimeString();
    } catch {
      return timeString;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-900 via-blue-800 to-green-800 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="bg-white/10 backdrop-blur-md rounded-2xl p-6 mb-8 border border-white/20">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-white mb-2">MLB Odds Movement</h1>
              <p className="text-blue-200">Live odds and line movement from Covers.com</p>
            </div>
            <button
              onClick={fetchOdds}
              disabled={loading}
              className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 disabled:bg-blue-800 text-white px-6 py-3 rounded-xl transition-all duration-200 shadow-lg hover:shadow-xl"
            >
              <RefreshCw className={`h-5 w-5 ${loading ? 'animate-spin' : ''}`} />
              {loading ? 'Updating...' : 'Refresh'}
            </button>
          </div>
        </div>

        {/* Last Updated */}
        {lastUpdated && (
          <div className="bg-green-500/20 backdrop-blur-sm rounded-lg p-3 mb-6 border border-green-400/30">
            <div className="flex items-center gap-2 text-green-200">
              <Clock className="h-4 w-4" />
              Last updated: {lastUpdated.toLocaleString()}
            </div>
          </div>
        )}

        {/* Error Display */}
        {error && (
          <div className="bg-red-500/20 backdrop-blur-sm rounded-lg p-4 mb-6 border border-red-400/30">
            <div className="flex items-center gap-2 text-red-200">
              <AlertCircle className="h-5 w-5" />
              Error: {error}
            </div>
          </div>
        )}

        {/* Games Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
          {oddsData.map((game, index) => (
            <div
              key={index}
              className="bg-white/10 backdrop-blur-md rounded-2xl p-6 border border-white/20 hover:bg-white/15 transition-all duration-300 hover:scale-105"
            >
              <div className="text-center mb-4">
                <div className="text-blue-200 text-sm font-medium mb-2">
                  {game.gameTime}
                </div>
              </div>

              {/* Teams and Odds */}
              <div className="space-y-4">
                <div className="flex items-center justify-between p-3 bg-white/10 rounded-lg">
                  <div className="text-white font-semibold">
                    {game.awayTeam}
                  </div>
                  <div className="text-right">
                    <div className="text-yellow-400 font-bold text-lg">
                      {game.odds.away}
                    </div>
                  </div>
                </div>

                <div className="text-center text-blue-300 text-sm font-medium">
                  VS
                </div>

                <div className="flex items-center justify-between p-3 bg-white/10 rounded-lg">
                  <div className="text-white font-semibold">
                    {game.homeTeam}
                  </div>
                  <div className="text-right">
                    <div className="text-yellow-400 font-bold text-lg">
                      {game.odds.home}
                    </div>
                  </div>
                </div>
              </div>

              {/* Line Movement Indicator */}
              <div className="mt-4 pt-4 border-t border-white/20">
                <div className="flex items-center justify-center gap-2 text-green-400">
                  <TrendingUp className="h-4 w-4" />
                  <span className="text-sm">Line Movement Available</span>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Line Movement Section */}
        {lineMovement.length > 0 && (
          <div className="mt-8 bg-white/10 backdrop-blur-md rounded-2xl p-6 border border-white/20">
            <h2 className="text-2xl font-bold text-white mb-4 flex items-center gap-2">
              <TrendingUp className="h-6 w-6" />
              Line Movement History
            </h2>
            <div className="overflow-x-auto">
              <table className="w-full text-white">
                <thead>
                  <tr className="border-b border-white/20">
                    <th className="text-left p-3">Time</th>
                    <th className="text-left p-3">Spread</th>
                    <th className="text-left p-3">Total</th>
                  </tr>
                </thead>
                <tbody>
                  {lineMovement.map((movement, index) => (
                    <tr key={index} className="border-b border-white/10">
                      <td className="p-3 text-blue-200">{movement.time}</td>
                      <td className="p-3 text-yellow-400">{movement.spread}</td>
                      <td className="p-3 text-green-400">{movement.total}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* No Data Message */}
        {!loading && oddsData.length === 0 && !error && (
          <div className="bg-white/10 backdrop-blur-md rounded-2xl p-12 text-center border border-white/20">
            <div className="text-white/60 text-lg">
              No odds data available. Click refresh to load data.
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default MLBOddsDashboard;