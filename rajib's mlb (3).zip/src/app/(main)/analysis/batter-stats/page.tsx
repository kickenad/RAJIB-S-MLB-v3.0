
// src/app/(main)/analysis/batter-stats/page.tsx
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Loader2, User, Users, Flame } from 'lucide-react';
import { getGamesForDate, getTeamRoster, type MlbGame } from '@/lib/mlb';
import { fetchBatterStats, type HittingStats } from '@/lib/mlb-stats';
import { format } from 'date-fns';
import { toZonedTime } from 'date-fns-tz';
import { Separator } from '@/components/ui/separator';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { unstable_noStore as noStore } from 'next/cache';

// --- TYPE DEFINITIONS ---
interface PlayerWithStats extends MlbPlayer {
  stats: HittingStats | null;
}
// This was defined in the mlb lib but not exported, so redefining here
// to avoid breaking lib changes.
export interface MlbPlayer {
  id: number;
  fullName: string;
  primaryPosition: {
    code: string;
    name: string;
    type: string;
    abbreviation: string;
  }
}

interface TeamWithTopHitters {
  id: number;
  name: string;
  topHitters: PlayerWithStats[];
}

interface GameWithTopHitters extends MlbGame {
  awayTeamData: TeamWithTopHitters;
  homeTeamData: TeamWithTopHitters;
}


// --- SERVER-SIDE HELPER FUNCTIONS ---

const getTeamTopHitters = async (teamId: number, teamName: string): Promise<TeamWithTopHitters> => {
    const roster = await getTeamRoster(teamId);
    
    // Non-pitchers are more likely to be key hitters, and ensure they have a position defined.
    const positionPlayers = roster.filter(p => {
        return p.person.primaryPosition && p.person.primaryPosition.type !== 'Pitcher';
    });

    const playersWithStats: PlayerWithStats[] = await Promise.all(
        positionPlayers.map(async (player) => {
            const stats = await fetchBatterStats(player.person.id);
            return { ...player.person, stats };
        })
    );

    // Filter for players with a reasonable number of at-bats to avoid small sample sizes
    const validPlayers = playersWithStats.filter(p => p.stats && p.stats.atBats && p.stats.atBats > 20);

    // Sort by OPS (descending) as a primary metric for "top hitter"
    validPlayers.sort((a, b) => parseFloat(b.stats?.ops ?? '0') - parseFloat(a.stats?.ops ?? '0'));

    return {
        id: teamId,
        name: teamName,
        topHitters: validPlayers.slice(0, 3)
    };
};

const getHitterData = async (): Promise<GameWithTopHitters[]> => {
    noStore(); // Ensures this runs dynamically on each request
    const todayStr = format(new Date(), 'yyyy-MM-dd');
    const games = await getGamesForDate(todayStr);

    const enrichedGames = await Promise.all(
        games.map(async (game) => {
            const [awayTeamData, homeTeamData] = await Promise.all([
                getTeamTopHitters(game.teams.away.team.id, game.teams.away.team.name),
                getTeamTopHitters(game.teams.home.team.id, game.teams.home.team.name)
            ]);
            return { ...game, awayTeamData, homeTeamData };
        })
    );

    return enrichedGames;
}


// --- UI COMPONENTS ---

function StatPill({ label, value }: { label: string, value?: string | number }) {
    return (
        <div className="flex flex-col items-center bg-secondary/50 p-2 rounded-md text-center">
            <span className="text-xs font-semibold text-muted-foreground">{label}</span>
            <span className="text-sm font-bold text-foreground">{value ?? 'N/A'}</span>
        </div>
    )
}

function HitterCard({ hitter }: { hitter: PlayerWithStats }) {
    const fallback = hitter.fullName.split(' ').map(n => n[0]).join('');
    
    return (
        <div className="p-3 rounded-lg border bg-card/50 flex gap-4 items-center">
            <Avatar>
                <AvatarImage src={`https://img.mlbstatic.com/mlb-photos/image/upload/d_people:generic_headshot.png/w_120,h_120,q_auto:best/v1/people/${hitter.id}/headshot/67/current`} alt={hitter.fullName} />
                <AvatarFallback>{fallback}</AvatarFallback>
            </Avatar>
            <div className="flex-1 space-y-2">
                <div>
                     <h4 className="font-bold truncate text-sm leading-tight">{hitter.fullName}</h4>
                     <p className="text-xs text-muted-foreground">{hitter.primaryPosition?.name ?? 'N/A'}</p>
                </div>
                <div className="grid grid-cols-4 gap-1.5">
                    <StatPill label="AVG" value={hitter.stats?.avg} />
                    <StatPill label="HR" value={hitter.stats?.homeRuns} />
                    <StatPill label="RBI" value={hitter.stats?.rbi} />
                    <StatPill label="OPS" value={hitter.stats?.ops} />
                </div>
            </div>
        </div>
    )
}

function HitterComparisonCard({ game }: { game: GameWithTopHitters }) {

    return (
        <Card>
            <CardHeader>
                <CardTitle className="text-xl">{game.teams.away.team.name} @ {game.teams.home.team.name}</CardTitle>
                <CardDescription>
                    {format(toZonedTime(game.gameDate, 'America/New_York'), 'p')} ET at {game.venue.name}
                </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
                 <div>
                    <h3 className="font-semibold text-base mb-2 text-center">{game.awayTeamData.name} Top Hitters</h3>
                     <div className="space-y-2">
                         {game.awayTeamData.topHitters.length > 0 ? (
                            game.awayTeamData.topHitters.map(hitter => <HitterCard key={hitter.id} hitter={hitter} />)
                         ) : <p className="text-sm text-center text-muted-foreground">No qualifying hitters found.</p>}
                    </div>
                </div>

                <Separator />

                <div>
                    <h3 className="font-semibold text-base mb-2 text-center">{game.homeTeamData.name} Top Hitters</h3>
                     <div className="space-y-2">
                        {game.homeTeamData.topHitters.length > 0 ? (
                            game.homeTeamData.topHitters.map(hitter => <HitterCard key={hitter.id} hitter={hitter} />)
                         ) : <p className="text-sm text-center text-muted-foreground">No qualifying hitters found.</p>}
                    </div>
                </div>
            </CardContent>
        </Card>
    );
}


// --- MAIN PAGE COMPONENT (SERVER COMPONENT) ---
export default async function BatterAnalysisPage() {
    const hitterData = await getHitterData();

    return (
        <div className="space-y-6">
            <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
                <div>
                    <h1 className="text-3xl font-bold tracking-tight flex items-center gap-2">
                        <Flame className="h-7 w-7 text-primary" />
                        Batter Analysis
                    </h1>
                    <p className="text-muted-foreground">Top 3 offensive threats for each team playing today, ranked by OPS.</p>
                </div>
            </div>

            {hitterData.length > 0 ? (
                <div className="grid gap-6 md:grid-cols-1 lg:grid-cols-2 xl:grid-cols-3">
                    {hitterData.map(game => (
                        <HitterComparisonCard key={game.gamePk} game={game} />
                    ))}
                </div>
            ) : (
                <Card>
                    <CardContent className="p-16 flex flex-col items-center justify-center text-center">
                         <Users className="h-16 w-16 text-muted-foreground mb-4" />
                        <h3 className="text-xl font-semibold">No Games Found</h3>
                        <p className="text-muted-foreground">There are no games scheduled for today.</p>
                    </CardContent>
                </Card>
            )}
        </div>
    );
}

