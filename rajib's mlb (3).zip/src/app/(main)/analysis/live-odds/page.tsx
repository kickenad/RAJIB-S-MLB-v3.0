
'use client';

import React, { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { AlertTriangle, Loader2, Clock, Users, User, Gamepad2 } from 'lucide-react';
import { format } from 'date-fns';
import { toZonedTime, format as formatTz } from 'date-fns-tz';

const API_KEY = process.env.NEXT_PUBLIC_ODDS_API_KEY;
const BASE_URL = 'https://api.the-odds-api.com/v4/sports/baseball_mlb/odds';

interface Outcome {
  name: string;
  price: number;
  point?: number;
  description?: string; // For player props
}

interface Market {
  key: string;
  last_update: string;
  outcomes: Outcome[];
}

interface Bookmaker {
  key: string;
  title: string;
  last_update: string;
  markets: Market[];
}

export interface GameOdds {
  id: string;
  sport_key: string;
  sport_title: string;
  commence_time: string;
  home_team: string;
  away_team: string;
  bookmakers: Bookmaker[];
}

const fetchOddsFromAPI = async (): Promise<GameOdds[] | null> => {
    if (!API_KEY) {
        console.warn("Odds API Key is missing. Skipping API fetch.");
        // Return an empty array or handle as a non-critical error
        return [];
    }
    const markets = 'h2h,spreads,totals';
    const url = `${BASE_URL}?regions=us&markets=${markets}&oddsFormat=american&apiKey=${API_KEY}`;
    
    try {
        const response = await fetch(url);
        if (!response.ok) {
            const errorData = await response.json();
            console.error('Error fetching odds:', errorData.message);
            throw new Error(`Failed to fetch odds from the API. ${errorData.message || ''}`);
        }
        const data = await response.json();
        return data as GameOdds[];
    } catch (error: any) {
        console.error('Error fetching odds:', error.message);
        throw error;
    }
};

function MarketDisplay({ market, title }: { market: { outcomes: { name: string, price: number, point?: number, description?: string }[] }, title: string }) {
    return (
        <div className="text-sm p-3 rounded-lg bg-secondary/30">
            <h4 className="font-semibold text-primary mb-2">{title}</h4>
            <div className="space-y-1">
                 {market.outcomes.map((outcome, oi) => (
                    <div key={oi} className="flex justify-between items-center text-muted-foreground p-2 rounded-md">
                        <span>
                            {outcome.name}
                            {outcome.point ? ` (${outcome.point})` : ''}
                            {outcome.description ? <span className="text-xs block text-muted-foreground/80">{outcome.description}</span> : ''}
                        </span>
                        <span className="font-mono font-bold text-foreground">{outcome.price > 0 ? `+${outcome.price}` : outcome.price}</span>
                    </div>
                ))}
            </div>
        </div>
    );
}

function GameOddsCard({ game }: { game: GameOdds }) {
    const gameTimeET = toZonedTime(game.commence_time, 'America/New_York');
    const formattedTime = formatTz(gameTimeET, 'p', { timeZone: 'America/New_York' });

    const liveBookmaker = game.bookmakers.find(b => b.key !== 'manual' && b.markets.length > 0);
    const manualBookmaker = game.bookmakers.find(b => b.key === 'manual');
    
    // Main markets from live odds if available
    const mainMarkets = liveBookmaker ? liveBookmaker.markets.filter(m => ['h2h', 'spreads', 'totals'].includes(m.key)) : [];

    // All manual markets from local storage upload
    const manualMarkets = manualBookmaker?.markets || [];
    
    // Group manual markets into player and team props
    const playerProps = manualMarkets.filter(m => m.outcomes && m.outcomes.some(o => o.name && !o.name.toLowerCase().includes('team')));
    const teamProps = manualMarkets.filter(m => m.outcomes && m.outcomes.some(o => o.name && o.name.toLowerCase().includes('team')));
    
    const getMarketTitle = (marketKey: string) => {
        const title = marketKey.split('-')[0].replace(/_/g, ' ');
        return title.charAt(0).toUpperCase() + title.slice(1);
    }
    
    const hasLiveOdds = mainMarkets.length > 0;
    const hasManualOdds = manualMarkets.length > 0;
    const bookmakerTitle = liveBookmaker?.title || (hasManualOdds ? 'Manual Odds' : 'No Odds Available');
    const lastUpdate = liveBookmaker?.last_update || (hasManualOdds ? manualBookmaker?.last_update : new Date().toISOString());

    return (
        <Card>
          <Accordion type="single" collapsible className="w-full">
            <AccordionItem value={game.id} className="border-b-0">
                <AccordionTrigger className="p-6 hover:no-underline">
                     <div className="w-full">
                        <CardTitle>{game.away_team} @ {game.home_team}</CardTitle>
                        <CardDescription className="flex items-center gap-4 mt-2">
                          <span>{format(gameTimeET, 'eeee, MMMM d')} &bull; {formattedTime}</span>
                          <span className="text-xs text-muted-foreground/80">
                              {bookmakerTitle} @ {formatTz(toZonedTime(lastUpdate, 'America/New_York'), 'p')}
                          </span>
                        </CardDescription>
                    </div>
                </AccordionTrigger>
                <AccordionContent className="p-6 pt-0">
                    <div className="space-y-4">
                        {hasLiveOdds && (
                            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                                {mainMarkets.map((market) => {
                                    const marketGroups: Record<string, string> = {
                                        'h2h': 'Moneyline',
                                        'spreads': 'Point Spread',
                                        'totals': 'Total Runs (Over/Under)',
                                    };
                                    const title = marketGroups[market.key] || market.key;
                                    return <MarketDisplay key={market.key} market={market} title={title} />;
                                })}
                            </div>
                        )}
                        
                        {hasManualOdds ? (
                            <Accordion type="multiple" className="w-full space-y-2">
                                {teamProps.length > 0 && (
                                <AccordionItem value="team-props">
                                    <AccordionTrigger className="text-lg font-semibold bg-secondary/50 px-4 rounded-md">
                                        <div className="flex items-center gap-2">
                                            <Users className="h-5 w-5" />
                                            Team Props
                                        </div>
                                    </AccordionTrigger>
                                    <AccordionContent className="pt-4 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                                        {teamProps.map((market) => (
                                            <MarketDisplay key={market.key} market={market} title={getMarketTitle(market.key)} />
                                        ))}
                                    </AccordionContent>
                                </AccordionItem>
                                )}

                                {playerProps.length > 0 && (
                                <AccordionItem value="player-props">
                                    <AccordionTrigger className="text-lg font-semibold bg-secondary/50 px-4 rounded-md">
                                         <div className="flex items-center gap-2">
                                            <User className="h-5 w-5" />
                                            Player Props
                                        </div>
                                    </AccordionTrigger>
                                    <AccordionContent className="pt-4 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                                        {playerProps.map((market) => (
                                            <MarketDisplay key={market.key} market={market} title={getMarketTitle(market.key)} />
                                        ))}
                                    </AccordionContent>
                                </AccordionItem>
                                )}
                            </Accordion>
                        ) : (
                            !hasLiveOdds && <p className="text-center text-muted-foreground">No odds available for this game yet.</p>
                        )}
                    </div>
                </AccordionContent>
            </AccordionItem>
          </Accordion>
        </Card>
    );
}

export default function RealTimeOddsPage() {
    const [oddsData, setOddsData] = useState<GameOdds[] | null>(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);
    const [lastUpdated, setLastUpdated] = useState<string | null>(null);

    const loadOdds = async () => {
        setLoading(true);
        setError(null);
        
        try {
            // Fetch from API
            const apiOdds = await fetchOddsFromAPI() || [];
            
            // Fetch from LocalStorage
            const manualOddsKey = 'manual_mlb_odds';
            const manualOddsData: Record<string, GameOdds> = JSON.parse(localStorage.getItem(manualOddsKey) || '{}');

            // Merge manual odds into API odds
            const combinedOddsMap = new Map<string, GameOdds>();

            // First, add all API odds to the map
            apiOdds.forEach(game => {
                const gameKey = `${game.home_team}_vs_${game.away_team}`.replace(/ /g, '_');
                combinedOddsMap.set(gameKey, game);
            });
            
            // Now, merge or add manual odds
            Object.values(manualOddsData).forEach(manualGame => {
                const gameKey = `${manualGame.home_team}_vs_${manualGame.away_team}`.replace(/ /g, '_');
                const existingGame = combinedOddsMap.get(gameKey);
                const manualBookmaker = manualGame.bookmakers.find(b => b.key === 'manual');

                if (existingGame) {
                    // Game exists, merge the manual bookmaker data
                    if (manualBookmaker) {
                        // Remove old manual bookmaker if it exists, to replace with fresh data
                        existingGame.bookmakers = existingGame.bookmakers.filter(b => b.key !== 'manual');
                        existingGame.bookmakers.push(manualBookmaker);
                    }
                } else {
                    // Game does not exist in API data, add it entirely from manual data
                    combinedOddsMap.set(gameKey, manualGame);
                }
            });

            const combinedOdds = Array.from(combinedOddsMap.values());

            setOddsData(combinedOdds);
            setLastUpdated(new Date().toLocaleString());

        } catch (err: any) {
            setError(err.message || 'An unknown error occurred while fetching odds.');
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        loadOdds();
        
        // Also listen for changes in localStorage to re-load
        const handleStorageChange = (event: StorageEvent) => {
            if (event.key === 'manual_mlb_odds_last_updated') {
                loadOdds();
            }
        };

        window.addEventListener('storage', handleStorageChange);
        return () => {
          window.removeEventListener('storage', handleStorageChange);
        };
    }, []);
    
    if (loading) {
        return (
            <div className="flex justify-center items-center h-full min-h-[400px]">
                <Loader2 className="h-10 w-10 animate-spin text-accent" />
            </div>
        );
    }
    
    if (error) {
        return (
             <div className="space-y-6">
                 <h1 className="text-3xl font-bold tracking-tight">Real-Time Odds</h1>
                 <Alert variant="destructive">
                    <AlertTriangle className="h-4 w-4" />
                    <AlertTitle>Error Fetching Odds</AlertTitle>
                    <AlertDescription>{error}</AlertDescription>
                </Alert>
            </div>
        );
    }

    if (!oddsData || oddsData.length === 0) {
        return (
             <div className="space-y-6">
                <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
                    <div>
                        <h1 className="text-3xl font-bold tracking-tight">Real-Time Odds</h1>
                        <p className="text-muted-foreground">Live market odds from top US sportsbooks. Data from The Odds API.</p>
                    </div>
                </div>
                 <Card>
                    <CardContent className="p-16 flex flex-col items-center justify-center text-center">
                         <Gamepad2 className="h-16 w-16 text-muted-foreground mb-4" />
                        <h3 className="text-xl font-semibold">No Odds Available</h3>
                        <p className="text-muted-foreground">No MLB odds are available at the moment. This can happen on off-days or when markets are closed. You can upload odds manually from the Admin dashboard.</p>
                    </CardContent>
                </Card>
            </div>
        );
    }

    return (
        <div className="space-y-6">
            <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
                <div>
                  <h1 className="text-3xl font-bold tracking-tight">Real-Time Odds</h1>
                  <p className="text-muted-foreground">Live market odds from top US sportsbooks. Data from The Odds API.</p>
                </div>
                {lastUpdated && (
                    <div className="text-sm text-muted-foreground flex items-center gap-2">
                        <Clock className="h-4 w-4" />
                        <span>Last updated: {lastUpdated}</span>
                    </div>
                )}
            </div>
            <div className="space-y-4">
                {oddsData.map((game) => (
                    <GameOddsCard key={game.id} game={game} />
                ))}
            </div>
        </div>
    );
}
