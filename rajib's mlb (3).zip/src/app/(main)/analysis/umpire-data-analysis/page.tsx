import { Card, CardHeader, CardTitle, CardContent, CardDescription } from "@/components/ui/card";
import { Users } from "lucide-react";

export default function UmpireDataAnalysisPage() {
  return (
    <div className="space-y-4">
      <h1 className="text-3xl font-bold">Umpire Data Analysis</h1>
      <Card>
        <CardHeader>
          <CardTitle>Umpire Tendencies</CardTitle>
          <CardDescription>Analysis of umpire data and their impact on game outcomes.</CardDescription>
        </CardHeader>
        <CardContent>
           <div className="flex flex-col items-center justify-center text-center py-16 text-muted-foreground">
            <Users className="h-12 w-12 mb-4" />
            <h3 className="text-xl font-semibold text-foreground">Feature Coming Soon</h3>
            <p>Umpire data analysis is currently under development. Check back later!</p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
