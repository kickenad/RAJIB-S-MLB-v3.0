// src/app/(main)/analysis/probable-pitcher-analysis/page.tsx
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHeader, TableRow } from "@/components/ui/table";
import { Loader2, UserCheck, Users } from 'lucide-react';
import { getGamesForDate, type MlbGame } from '@/lib/mlb';
import { fetchPitcherStats, type PitcherStats } from '@/lib/mlb-stats';
import { format } from 'date-fns';
import { toZonedTime } from 'date-fns-tz';
import { Separator } from '@/components/ui/separator';
import { unstable_noStore as noStore } from 'next/cache';

// --- TYPE DEFINITIONS ---
interface ProbablePitcher extends MlbGame {
    awayPitcherStats?: PitcherStats | null;
    homePitcherStats?: PitcherStats | null;
}

// --- SERVER-SIDE HELPER FUNCTIONS ---

const getPitcherData = async (): Promise<ProbablePitcher[]> => {
    noStore(); // Opt out of caching for this specific fetch
    const todayStr = format(new Date(), 'yyyy-MM-dd');
    const games = await getGamesForDate(todayStr);

    const gamesWithPitchers = games.filter(
        game => game.teams.away.probablePitcher && game.teams.home.probablePitcher
    );

    const enrichedGames = await Promise.all(
        gamesWithPitchers.map(async (game) => {
            const [awayPitcherStats, homePitcherStats] = await Promise.all([
                fetchPitcherStats(game.teams.away.probablePitcher?.id),
                fetchPitcherStats(game.teams.home.probablePitcher?.id)
            ]);
            return { ...game, awayPitcherStats, homePitcherStats };
        })
    );

    return enrichedGames;
}


// --- UI COMPONENTS ---

function StatRow({ label, awayValue, homeValue }: { label: string, awayValue?: string | number, homeValue?: string | number }) {
    const awayDisplay = awayValue ?? 'N/A';
    const homeDisplay = homeValue ?? 'N/A';
    
    // Attempt to parse values for comparison, ignore if not numbers
    const awayNum = parseFloat(String(awayValue));
    const homeNum = parseFloat(String(homeValue));
    
    let awayClass = 'font-semibold';
    let homeClass = 'font-semibold';

    if (!isNaN(awayNum) && !isNaN(homeNum)) {
        // For ERA, WHIP, H/9, HR/9 lower is better. For others, higher is better.
        if (['ERA', 'WHIP', 'H/9', 'HR/9'].includes(label)) {
            if (awayNum < homeNum) awayClass += ' text-green-400';
            else if (homeNum < awayNum) homeClass += ' text-green-400';
        } else {
            if (awayNum > homeNum) awayClass += ' text-green-400';
            else if (homeNum > awayNum) homeClass += ' text-green-400';
        }
    }

    return (
        <TableRow>
            <TableCell className={awayClass}>{awayDisplay}</TableCell>
            <TableCell className="text-center text-muted-foreground font-medium">{label}</TableCell>
            <TableCell className={homeClass + " text-right"}>{homeDisplay}</TableCell>
        </TableRow>
    );
}

function PitcherComparisonCard({ game }: { game: ProbablePitcher }) {
    const awayPitcher = game.teams.away.probablePitcher;
    const homePitcher = game.teams.home.probablePitcher;

    return (
        <Card>
            <CardHeader>
                <CardTitle className="text-xl">{game.teams.away.team.name} @ {game.teams.home.team.name}</CardTitle>
                <CardDescription>
                    {format(toZonedTime(game.gameDate, 'America/New_York'), 'p')} ET at {game.venue.name}
                </CardDescription>
            </CardHeader>
            <CardContent>
                <div className="grid grid-cols-2 gap-4 mb-4 text-center">
                    <div>
                        <h4 className="font-bold truncate">{awayPitcher?.fullName ?? 'TBD'}</h4>
                        <p className="text-sm text-muted-foreground">Away Pitcher</p>
                    </div>
                     <div>
                        <h4 className="font-bold truncate">{homePitcher?.fullName ?? 'TBD'}</h4>
                        <p className="text-sm text-muted-foreground">Home Pitcher</p>
                    </div>
                </div>
                
                <Separator className="mb-4" />

                <Table>
                    <TableBody>
                        <StatRow label="ERA" awayValue={game.awayPitcherStats?.era} homeValue={game.homePitcherStats?.era} />
                        <StatRow label="WHIP" awayValue={game.awayPitcherStats?.whip} homeValue={game.homePitcherStats?.whip} />
                        <StatRow label="Record" awayValue={`${game.awayPitcherStats?.wins || 0}-${game.awayPitcherStats?.losses || 0}`} homeValue={`${game.homePitcherStats?.wins || 0}-${game.homePitcherStats?.losses || 0}`} />
                        <StatRow label="Innings" awayValue={game.awayPitcherStats?.inningsPitched} homeValue={game.homePitcherStats?.inningsPitched} />
                        <StatRow label="Strikeouts" awayValue={game.awayPitcherStats?.strikeouts} homeValue={game.homePitcherStats?.strikeouts} />
                        <StatRow label="Walks" awayValue={game.awayPitcherStats?.baseOnBalls} homeValue={game.homePitcherStats?.baseOnBalls} />
                        <StatRow label="K/BB Ratio" awayValue={game.awayPitcherStats?.strikeoutWalkRatio} homeValue={game.homePitcherStats?.strikeoutWalkRatio} />
                        <StatRow label="K/9" awayValue={game.awayPitcherStats?.strikeoutsPer9Inn} homeValue={game.homePitcherStats?.strikeoutsPer9Inn} />
                        <StatRow label="H/9" awayValue={game.awayPitcherStats?.hitsPer9Inn} homeValue={game.homePitcherStats?.hitsPer9Inn} />
                        <StatRow label="HR/9" awayValue={game.awayPitcherStats?.homeRunsPer9} homeValue={game.homePitcherStats?.homeRunsPer9} />
                    </TableBody>
                </Table>

            </CardContent>
        </Card>
    );
}


// --- MAIN PAGE COMPONENT (SERVER COMPONENT) ---
export default async function ProbablePitcherAnalysisPage() {
    const pitcherData = await getPitcherData();

    return (
        <div className="space-y-6">
            <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
                <div>
                    <h1 className="text-3xl font-bold tracking-tight flex items-center gap-2">
                        <UserCheck className="h-7 w-7 text-primary" />
                        Probable Pitcher Analysis
                    </h1>
                    <p className="text-muted-foreground">Side-by-side comparison of today's starting pitchers.</p>
                </div>
            </div>

            {pitcherData.length > 0 ? (
                <div className="grid gap-6 md:grid-cols-1 lg:grid-cols-2 xl:grid-cols-3">
                    {pitcherData.map(game => (
                        <PitcherComparisonCard key={game.gamePk} game={game} />
                    ))}
                </div>
            ) : (
                <Card>
                    <CardContent className="p-16 flex flex-col items-center justify-center text-center">
                         <Users className="h-16 w-16 text-muted-foreground mb-4" />
                        <h3 className="text-xl font-semibold">No Pitcher Matchups Found</h3>
                        <p className="text-muted-foreground">There are no games with probable pitchers listed for today. This could be due to an off-day or lineups not being confirmed yet.</p>
                    </CardContent>
                </Card>
            )}
        </div>
    );
}
