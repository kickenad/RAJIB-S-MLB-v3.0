// src/app/(main)/analysis/bullpen-analysis/page.tsx
import { Card, CardHeader, CardTitle, CardContent, CardDescription } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Users, AlertTriangle } from "lucide-react";
import { getGamesForDate, type MlbGame } from '@/lib/mlb';
import { bullpenUsageData, type PitcherUsage } from '@/lib/bullpenData';
import { format } from 'date-fns';
import { unstable_noStore as noStore } from 'next/cache';

// --- TYPE DEFINITIONS ---
interface GameWithBullpen {
    game: MlbGame;
    awayBullpen: PitcherUsage[];
    homeBullpen: PitcherUsage[];
}

// --- SERVER-SIDE HELPER FUNCTIONS ---
const getBullpenDataForToday = async (): Promise<GameWithBullpen[]> => {
    noStore(); // Ensures this runs dynamically on each request
    const todayStr = format(new Date(), 'yyyy-MM-dd');
    const games = await getGamesForDate(todayStr);

    const gamesWithBullpens: GameWithBullpen[] = [];

    for (const game of games) {
        const awayTeamName = game.teams.away.team.name;
        const homeTeamName = game.teams.home.team.name;
        
        const awayBullpen = bullpenUsageData.bullpenUsage[awayTeamName] || [];
        const homeBullpen = bullpenUsageData.bullpenUsage[homeTeamName] || [];

        gamesWithBullpens.push({
            game,
            awayBullpen,
            homeBullpen,
        });
    }
    return gamesWithBullpens;
};


// --- UI COMPONENTS ---
function BullpenTable({ teamName, players }: { teamName: string; players: PitcherUsage[] }) {
    if (players.length === 0) {
        return (
             <div className="flex flex-col items-center justify-center text-center py-8 text-muted-foreground">
                <AlertTriangle className="h-8 w-8 mb-2" />
                <p className="font-semibold text-foreground">No Bullpen Data</p>
                <p className="text-sm">No usage data found for the {teamName}.</p>
            </div>
        )
    }
    
    return (
        <div>
            <h3 className="text-lg font-semibold mb-2 text-center">{teamName}</h3>
            <div className="overflow-x-auto rounded-lg border">
                <Table>
                    <TableHeader>
                        <TableRow>
                            <TableHead>Player</TableHead>
                            <TableHead className="text-right">Last 3 Days</TableHead>
                            <TableHead className="text-right">Last 5 Days</TableHead>
                        </TableRow>
                    </TableHeader>
                    <TableBody>
                        {players.map(player => (
                            <TableRow key={player.playerName}>
                                <TableCell className="font-medium">{player.playerName}</TableCell>
                                <TableCell className="text-right font-mono">{player.last3DaysPitches}</TableCell>
                                <TableCell className="text-right font-mono">{player.last5DaysPitches}</TableCell>
                            </TableRow>
                        ))}
                    </TableBody>
                </Table>
            </div>
        </div>
    )
}


// --- MAIN PAGE COMPONENT (SERVER COMPONENT) ---
export default async function BullpenAnalysisPage() {
  const bullpenData = await getBullpenDataForToday();

  return (
    <div className="space-y-6">
        <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
            <div>
                <h1 className="text-3xl font-bold tracking-tight flex items-center gap-2">
                    <Users className="h-7 w-7 text-primary" />
                    Bullpen Usage Analysis
                </h1>
                <p className="text-muted-foreground">Recent pitch counts for each team's relief pitchers.</p>
            </div>
        </div>

      {bullpenData.length > 0 ? (
        <div className="space-y-8">
            {bullpenData.map(data => (
                 <Card key={data.game.gamePk}>
                    <CardHeader>
                        <CardTitle>{data.game.teams.away.team.name} @ {data.game.teams.home.team.name}</CardTitle>
                        <CardDescription>Side-by-side bullpen workload comparison.</CardDescription>
                    </CardHeader>
                    <CardContent className="grid md:grid-cols-2 gap-8">
                        <BullpenTable teamName={data.game.teams.away.team.name} players={data.awayBullpen} />
                        <BullpenTable teamName={data.game.teams.home.team.name} players={data.homeBullpen} />
                    </CardContent>
                </Card>
            ))}
        </div>
      ) : (
        <Card>
            <CardContent className="p-16 flex flex-col items-center justify-center text-center">
                 <Users className="h-16 w-16 text-muted-foreground mb-4" />
                <h3 className="text-xl font-semibold">No Games Scheduled Today</h3>
                <p className="text-muted-foreground max-w-md">There are no games scheduled for today, so no bullpen data is available.</p>
            </CardContent>
        </Card>
      )}
    </div>
  );
}
