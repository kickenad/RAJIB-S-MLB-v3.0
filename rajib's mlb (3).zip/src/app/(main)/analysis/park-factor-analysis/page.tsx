// src/app/(main)/analysis/park-factor-analysis/page.tsx
import { Crosshair, Users } from "lucide-react";
import { getGamesForDate, type MlbGame } from '@/lib/mlb';
import { parkFactorsDB, type ParkFactorSet } from '@/lib/parkFactors';
import { format } from 'date-fns';
import { unstable_noStore as noStore } from 'next/cache';
import { Card, CardContent } from "@/components/ui/card";
import { ParkFactorInfoCard } from "@/components/mlb/park-factor-card";

// --- TYPE DEFINITIONS ---
export interface GameWithParkFactors {
    game: MlbGame;
    parkFactors: ParkFactorSet;
}

// --- SERVER-SIDE HELPER FUNCTIONS ---
const getParkFactorDataForToday = async (): Promise<GameWithParkFactors[]> => {
    noStore(); // Ensures this runs dynamically on each request
    const todayStr = format(new Date(), 'yyyy-MM-dd');
    const games = await getGamesForDate(todayStr);

    const gamesWithFactors: GameWithParkFactors[] = [];

    for (const game of games) {
        // Normalize venue names if necessary
        let venueName = game.venue.name;
        if (venueName === "Angel Stadium of Anaheim") {
            venueName = "Angel Stadium";
        }
        
        if (parkFactorsDB[venueName]) {
            gamesWithFactors.push({
                game,
                parkFactors: parkFactorsDB[venueName]
            });
        }
    }
    return gamesWithFactors;
};


// --- MAIN PAGE COMPONENT (SERVER COMPONENT) ---
export default async function ParkFactorAnalysisPage() {
    const parkFactorData = await getParkFactorDataForToday();

    return (
        <div className="space-y-6">
             <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
                <div>
                    <h1 className="text-3xl font-bold tracking-tight flex items-center gap-2">
                        <Crosshair className="h-7 w-7 text-primary" />
                        Park Factor Analysis
                    </h1>
                    <p className="text-muted-foreground">How today's ballparks influence hitting and pitching outcomes.</p>
                </div>
            </div>

            {parkFactorData.length > 0 ? (
                 <div className="grid gap-6 md:grid-cols-1 lg:grid-cols-2 xl:grid-cols-3">
                    {parkFactorData.map(data => (
                        <ParkFactorInfoCard key={data.game.gamePk} data={data} />
                    ))}
                </div>
            ) : (
                 <Card>
                    <CardContent className="p-16 flex flex-col items-center justify-center text-center">
                         <Users className="h-16 w-16 text-muted-foreground mb-4" />
                        <h3 className="text-xl font-semibold">No Games with Park Data Today</h3>
                        <p className="text-muted-foreground max-w-md">There are either no games scheduled for today, or the scheduled games are in venues not present in our park factor database.</p>
                    </CardContent>
                </Card>
            )}
        </div>
    );
}
