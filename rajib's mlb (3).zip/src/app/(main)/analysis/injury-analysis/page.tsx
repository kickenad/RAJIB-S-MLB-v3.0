// src/app/(main)/analysis/injury-analysis/page.tsx
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { AlertTriangle, ShieldAlert, Webhook, Users } from 'lucide-react';
import { format, subMonths, isToday } from 'date-fns';
import { unstable_noStore as noStore } from 'next/cache';
import axios from 'axios';
import { getGamesForDate, type MlbGame } from '@/lib/mlb';

// --- TYPE DEFINITIONS ---
interface MlbTeam {
  id: number;
  name: string;
  abbreviation: string;
}

interface MlbApiTeam {
  id: number;
  teamName: string;
  abbreviation: string;
}

interface MlbTransaction {
  id: number;
  date: string;
  effectiveDate?: string;
  resolutionDate?: string;
  description: string;
  typeCode: string;
  person?: {
    id: number;
    fullName: string;
  };
  toTeam?: {
    id: number;
  };
}

interface Injury {
    transactionId: number;
    playerId?: number;
    playerName?: string;
    teamId: number;
    teamName: string;
    description: string;
    date: string;
    effectiveDate?: string;
    resolutionDate?: string;
}

interface GameWithInjuries {
    game: MlbGame;
    injuries: Injury[];
}


// --- SERVER-SIDE CACHE ---
interface Cache<T> {
  data: T | null;
  lastFetched: Date | null;
}

const injuryCache: Cache<Injury[]> = {
  data: null,
  lastFetched: null,
};

const isCacheValid = (cache: Cache<any>): boolean => {
  if (!cache.data || !cache.lastFetched) {
    return false;
  }
  return isToday(cache.lastFetched);
};


// --- HELPER FUNCTIONS ---

async function fetchMlbTeams(year: number): Promise<Map<number, MlbApiTeam>> {
  const url = `https://statsapi.mlb.com/api/v1/teams?sportId=1&season=${year}`;
  try {
    const response = await axios.get(url);
    const teams: MlbTeam[] = response.data.teams;
    const teamMap = new Map<number, MlbApiTeam>();
    teams.forEach(team => {
      teamMap.set(team.id, {
        id: team.id,
        teamName: team.name,
        abbreviation: team.abbreviation,
      });
    });
    return teamMap;
  } catch (error) {
    console.error(`Error fetching team info for ${year}:`, error);
    return new Map();
  }
}

async function scrapeIlData(startDate: string, endDate: string): Promise<Injury[]> {
  const url = `https://statsapi.mlb.com/api/v1/transactions?startDate=${startDate}&endDate=${endDate}&sportId=1`;
  const year = new Date(startDate).getFullYear();
  const teamsMap = await fetchMlbTeams(year);
  const allInjuries: Injury[] = [];
  const injuryKeywords = /injured list|il/i;

  try {
    const response = await axios.get(url);
    const transactions: MlbTransaction[] = response.data.transactions || [];

    for (const trx of transactions) {
      if (
        trx.typeCode === 'SC' &&
        trx.description &&
        injuryKeywords.test(trx.description) &&
        trx.toTeam?.id &&
        trx.person
      ) {
        const teamInfo = teamsMap.get(trx.toTeam.id);
        if (teamInfo) {
          allInjuries.push({
            transactionId: trx.id,
            playerId: trx.person.id,
            playerName: trx.person.fullName,
            teamId: trx.toTeam.id,
            teamName: teamInfo.teamName,
            description: trx.description,
            date: trx.date,
            effectiveDate: trx.effectiveDate,
            resolutionDate: trx.resolutionDate,
          });
        }
      }
    }
  } catch (error) {
    console.error(`Failed to fetch data from MLB API:`, error);
    throw new Error('Failed to fetch data from MLB API.');
  }
  
  allInjuries.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  
  return allInjuries;
}

// This function now runs on the server, directly fetching the data.
async function fetchInjuriesForToday(): Promise<{ gamesWithInjuries: GameWithInjuries[], error: string | null }> {
  noStore();

  let allInjuries: Injury[] = [];
  
  // Check cache first for all injuries
  if (isCacheValid(injuryCache) && injuryCache.data) {
    console.log("Serving all injury data from cache.");
    allInjuries = injuryCache.data;
  } else {
    console.log("Cache invalid, fetching fresh injury data.");
    const today = new Date();
    const threeMonthsAgo = subMonths(today, 3);
    const startDate = format(threeMonthsAgo, 'yyyy-MM-dd');
    const endDate = format(today, 'yyyy-MM-dd');
    try {
        allInjuries = await scrapeIlData(startDate, endDate);
        injuryCache.data = allInjuries;
        injuryCache.lastFetched = new Date();
    } catch (e: any) {
        return { gamesWithInjuries: [], error: `Failed to fetch injury data: ${e.message}` };
    }
  }
  
  // Get today's games and filter injuries by teams playing
  try {
    const todayStr = format(new Date(), 'yyyy-MM-dd');
    const games = await getGamesForDate(todayStr);

    if (games.length === 0) {
        return { gamesWithInjuries: [], error: null };
    }

    const gamesWithInjuries = games.map(game => {
        const homeTeamId = game.teams.home.team.id;
        const awayTeamId = game.teams.away.team.id;
        const gameInjuries = allInjuries.filter(
            injury => injury.teamId === homeTeamId || injury.teamId === awayTeamId
        );
        return { game, injuries: gameInjuries };
    });

    return { gamesWithInjuries, error: null };

  } catch (e:any) {
     return { gamesWithInjuries: [], error: `Failed to fetch game data: ${e.message}` };
  }
};


// --- UI COMPONENTS ---
function InjuryTable({ injuries }: { injuries: Injury[] }) {
    if (injuries.length === 0) {
        return <p className="text-sm text-center text-muted-foreground p-4">No recent injury transactions for these teams.</p>
    }
    return (
         <div className="overflow-x-auto">
            <Table>
                <TableHeader>
                <TableRow>
                    <TableHead>Date</TableHead>
                    <TableHead>Team</TableHead>
                    <TableHead>Player</TableHead>
                    <TableHead>Description</TableHead>
                </TableRow>
                </TableHeader>
                <TableBody>
                {injuries.map((injury) => (
                    <TableRow key={injury.transactionId}>
                    <TableCell>{format(new Date(injury.date), 'MMM d, yyyy')}</TableCell>
                    <TableCell>{injury.teamName}</TableCell>
                    <TableCell>{injury.playerName || 'N/A'}</TableCell>
                    <TableCell>{injury.description}</TableCell>
                    </TableRow>
                ))}
                </TableBody>
            </Table>
        </div>
    )
}

// --- MAIN PAGE COMPONENT (SERVER COMPONENT) ---
export default async function InjuryAnalysisPage() {
  const { gamesWithInjuries, error } = await fetchInjuriesForToday();

  const renderContent = () => {
    if (error) {
      return (
         <div className="flex flex-col items-center justify-center text-center py-16 text-destructive">
          <AlertTriangle className="h-12 w-12 mb-4" />
          <h3 className="text-xl font-semibold">An Error Occurred</h3>
          <p className="max-w-md">{error}</p>
        </div>
      );
    }

    if (gamesWithInjuries.length === 0) {
        return (
            <div className="flex flex-col items-center justify-center text-center py-16 text-muted-foreground">
                <Users className="h-12 w-12 mb-4" />
                <h3 className="text-xl font-semibold text-foreground">No Games Scheduled Today</h3>
                <p>There are no games on the schedule, so no injury data is displayed.</p>
            </div>
        )
    }

    return (
        <div className="space-y-6">
            {gamesWithInjuries.map(({ game, injuries }) => (
                <Card key={game.gamePk}>
                    <CardHeader>
                        <CardTitle>{game.teams.away.team.name} @ {game.teams.home.team.name}</CardTitle>
                        <CardDescription>Injury-related transactions for players on these teams.</CardDescription>
                    </CardHeader>
                    <CardContent className="p-0">
                        <InjuryTable injuries={injuries} />
                    </CardContent>
                </Card>
            ))}
        </div>
    );
  }

  return (
    <div className="space-y-6">
        <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
            <div>
                <h1 className="text-3xl font-bold tracking-tight flex items-center gap-2">
                    <ShieldAlert className="h-7 w-7 text-primary" />
                    Injury Analysis
                </h1>
                <p className="text-muted-foreground">
                    Live injury-related transactions for today's scheduled games (cached daily).
                </p>
            </div>
        </div>
        {renderContent()}
    </div>
  );
};
