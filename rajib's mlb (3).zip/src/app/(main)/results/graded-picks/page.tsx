import { Card, CardHeader, CardTitle, CardContent, CardDescription } from "@/components/ui/card";
import { ClipboardList } from "lucide-react";

export default function GradedPicksPage() {
  return (
    <div className="space-y-4">
      <h1 className="text-3xl font-bold">Graded Picks</h1>
      <Card>
        <CardHeader>
          <CardTitle>Historical Graded Picks</CardTitle>
          <CardDescription>View the results and grades of past AI-generated picks.</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col items-center justify-center text-center py-16 text-muted-foreground">
            <ClipboardList className="h-12 w-12 mb-4" />
            <h3 className="text-xl font-semibold text-foreground">Feature Coming Soon</h3>
            <p>The graded picks page is currently under development. Check back later!</p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
