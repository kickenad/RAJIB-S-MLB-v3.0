// src/app/(main)/layout.tsx
'use client';
import { Header } from '@/components/layout/header';
import { MainSidebar } from '@/components/layout/sidebar';
import { SidebarProvider, SidebarInset } from '@/components/ui/sidebar';
import { useAuth } from '@/hooks/useAuth';
import { useRouter } from 'next/navigation';
import { useEffect } from 'react';
import { Loader2 } from 'lucide-react';

export default function MainLayout({ children }: { children: React.ReactNode }) {
  const { user, loading, isAdmin } = useAuth();
  const router = useRouter();

  // useEffect(() => {
  //   if (!loading && !user) {
  //     router.replace('/login');
  //   }
  // }, [user, loading, router]);
  
  // if (loading) {
  //   return (
  //       <div className="flex h-screen w-full items-center justify-center bg-background">
  //           <Loader2 className="h-10 w-10 animate-spin text-primary" />
  //       </div>
  //   );
  // }

  // if (!user) {
  //   return null; // or a redirect component
  // }

  return (
    <SidebarProvider>
      <div className="flex min-h-screen">
        <MainSidebar />
        <SidebarInset className="flex flex-col">
          <Header />
          <main className="flex-1 overflow-y-auto p-4 md:p-6 lg:p-8">
            {children}
          </main>
        </SidebarInset>
      </div>
    </SidebarProvider>
  );
}
